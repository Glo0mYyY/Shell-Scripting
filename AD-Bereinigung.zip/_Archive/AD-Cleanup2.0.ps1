# Import the required modules
Import-Module ActiveDirectory

# Define the OUs to scan
$ous = "OU=AdmMagnt-Test,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net"#, "OU=Computers2,DC=domain,DC=com"

# Define the groups to exclude
$excludeGroups = "Group1", "Group2", "Group3"

# Define the comment pattern to mark computers for deletion
$commentPattern = "[d]"

# Define the number of days after which a computer should be marked for deletion
$disableDays = 50

# Define the number of months after which a disabled computer should be deleted
$deleteMonths = 9

# Define the path and name of the export file
$exportPath = "C:\temp\export.csv"

# Define the path and name of the log file
$Global:logFile = "C:\temp\AD-Cleanup.log"

# Get the current date
$currentDate = Get-Date

# Create an array to hold the export data
$exportData = @()

# Define LOG variables
[bool]$Global:Verbose = $false
$Global:MaxLogSizeInKB = 10240
$Global:ScriptName = $MyInvocation.MyCommand.Name
$Global:ScriptStatus = 'Success'

function LogIt {
    param (
        [Parameter(Mandatory = $true)]
        $message,
        [Parameter(Mandatory = $true)]
        $component,
        [Parameter(Mandatory = $true)]
        $type)
	
    switch ($type) {
        1 { $type = "Info" }
        2 { $type = "Warning" }
        3 { $type = "Error" }
        4 { $type = "Verbose" }
        default { $type = "Unknown" }
    }
	
    if (($type -eq "Verbose") -and ($Global:Verbose)) {
        $toLog = "{0} `$$<{1}><{2} {3}><thread={4}>" -f ($type + ":" + $message), ($Global:ScriptName + ":" + $component), (Get-Date -Format "MM-dd-yyyy"), (Get-Date -Format "HH:mm:ss.ffffff"), $pid
        $toLog | Out-File -Append -Encoding UTF8 -FilePath ("filesystem::{0}" -f $Global:LogFile)
        Write-Host $message
    }
    elseif ($type -ne "Verbose") {
        $toLog = "{0} `$$<{1}><{2} {3}><thread={4}>" -f ($type + ":" + $message), ($Global:ScriptName + ":" + $component), (Get-Date -Format "MM-dd-yyyy"), (Get-Date -Format "HH:mm:ss.ffffff"), $pid
        $toLog | Out-File -Append -Encoding UTF8 -FilePath ("filesystem::{0}" -f $Global:LogFile)
        Write-Host $message
    }
    if (($type -eq 'Warning') -and ($Global:ScriptStatus -ne 'Error')) { $Global:ScriptStatus = $type }
    if ($type -eq 'Error') { $Global:ScriptStatus = $type }
	
    if ((Get-Item $Global:LogFile).Length / 1KB -gt $Global:MaxLogSizeInKB) {
        $log = $Global:LogFile
        Remove-Item ($log.Replace(".log", ".lo_"))
        Rename-Item $Global:LogFile ($log.Replace(".log", ".lo_")) -Force
    }
}

LogIt -message "Starting script" -type 1 -component "Script"

foreach ($ou in $ous) {
    LogIt -message "Scanning OU: $ou" -type 1 -component "Script"

    # Get all computers in the OU
    $computers = Get-ADComputer -Filter * -SearchBase $ou

    foreach ($computer in $computers) {
        LogIt -message "Processing computer: $($computer.Name)" -type 1 -component "Script"

        # Check if the computer is a member of any of the excluded groups
        $memberOf = (Get-ADComputer $computer -Properties MemberOf).MemberOf
        if ((($memberOf | Where-Object { $excludeGroups.Contains($_) }) | Measure-Object).Count) {
            LogIt -message "$($computer.Name) is a member of excluded group(s)" -type 2
            continue
        }

        # Get the last logon timestamp of the computer
        [DateTime]$lastLogonDate = [DateTime]::FromFileTime((Get-ADComputer $computer -Properties LastLogonTimestamp).LastLogonTimestamp)

        # Check if the last logon date is older than the specified number of days and if the computer doesn't have a comment matching the pattern already
        if (($currentDate - $lastLogonDate).Days -gt $disableDays -and ($computer.Description -notmatch $commentPattern)) {
            LogIt -message "$($computer.Name) has not logged on for more than $disableDays days and does not have a comment matching the pattern already" -type 1 -component "Script"
            # Mark the computer with a comment and keep any existing comment behind it
            Set-ADComputer $computer -Description "$commentPattern $($currentDate.ToString("MM.yyyy"))_$($currentDate.AddMonths($deleteMonths).ToString("MM.yyyy"))_# $($computer.Description)"
            LogIt -message "$($computer.Name) has been marked with a comment" -type 1 -component "Script"
        }

        # Check if the computer is disabled and has been marked for deletion
        if (($computer.Enabled -eq $false) -and ($computer.Description -match $commentPattern)) {
            LogIt -message "$($computer.Name) is disabled and has been marked for deletion" -type 1 -component "Script"
            # Extract the deletion date from the comment 
            if ($computer.Description -match "$commentPattern \d{2}\.\d{4}_(\d{2}\.\d{4})_#") { 
                [DateTime]$deletionDate = [DateTime]::ParseExact($Matches[1], "MM.yyyy", [System.Globalization.CultureInfo]::InvariantCulture) 
            } 

            # Check if the current date is greater than or equal to the deletion date 
            if ($currentDate -ge $deletionDate) { 
                LogIt -message "$($computer.Name) has been disabled for longer than or equal to $deleteMonths months" -type 1 -component "Script"
                # Export Bitlocker Key, LAPS password, Groupmembership, Device Name and the deletion date into an excel sheet

                # Get the Bitlocker recovery key for the computer
                try {
                    LogIt -message "Getting Bitlocker recovery key for $($computer.Name)" -type 1 -component "Script"
                    $bitlockerKey = (Get-BitLockerKeyProtector -MountPoint "C:" -ComputerName $computer.Name | Where-Object { $_.KeyProtectorType -eq "RecoveryPassword" }).KeyProtectorId
                }
                catch {
                    LogIt -message "Failed to get Bitlocker recovery key for $($computer.Name)" -type 3 -component "Script"
                    $bitlockerKey = $null
                }

                # Get the LAPS password for the computer
                try {
                    LogIt -message "Getting LAPS password for $($computer.Name)" -type 1 -component "Script"
                    $lapsPassword = (Get-LapsADPassword -Identity $computer.Name).Password
                }
                catch {
                    LogIt -message "Failed to get LAPS password for $($computer.Name)" -type 3 -component "Script"
                    $lapsPassword = $null
                }

                # Create a custom object to hold the export data for this computer 
                $obj = New-Object PSObject 
                Add-Member –InputObject $obj –MemberType NoteProperty –Name "Device Name" –Value $computer.Name 
                Add-Member –InputObject $obj –MemberType NoteProperty –Name "Deletion Date" –Value (Get-Date) 
                Add-Member –InputObject $obj –MemberType NoteProperty –Name "Bitlocker Key" –Value $bitlockerKey 
                Add-Member –InputObject $obj –MemberType NoteProperty –Name "LAPS Password" –Value $lapsPassword 
                Add-Member –InputObject $obj –MemberType NoteProperty –Name "Group Membership" –Value ($memberOf | Out-String)

                # Add the custom object to the export data array 
                $exportData += $obj 

                # Delete the computer object from AD 
                Remove-ADComputer $computer –Confirm:$false 
                LogIt -message "$($computer.Name) has been deleted from AD" -type 1 -component "Script"
            }
        }

        # Check if a device is back online using LastLogonTimestamp instead of Test-Connection 
        if (($computer.Description –match $commentPattern) -and ($currentDate - $lastLogonDate).Days -le $disableDays) { 
            LogIt -message "$($computer.Name) is back online" -type 1 -component "Script"
            # Remove only new comment from description 
            Set-ADComputer $computer –Description ($computer.Description –replace "$commentPattern \d{2}\.\d{4}_\d{2}\.\d{4}_# ", "") 
            LogIt -message "New comment has been removed from $($computer.Name)" -type 1 -component "Script"
    }
}
}

LogIt -message "Exporting data" -type 1 -component "Script"

# Check if there is any data to export
if ($exportData.Count -gt 0) {
    # Check if the export file exists
    if (Test-Path $exportPath) {
        # Append the data to the existing file
        LogIt -message "Appending data to existing file: $exportPath" -type 1 -component "Script"
        $exportData | Export-Csv -Path $exportPath -NoTypeInformation -Force -Append
    }
    else {
        # Create the export file and path if they do not exist
        LogIt -message "Creating new file: $exportPath" -type 1 -component "Script"
        New-Item -ItemType File -Path $exportPath -Force

        # Export the data to the new file
        LogIt -message "Exporting data to new file: $exportPath" -type 1 -component "Script"
    }
}
else {
    LogIt -message "No data to export" -type 1 -component "Script"
}

LogIt -message "Script finished" -type 1 -component "Script"
