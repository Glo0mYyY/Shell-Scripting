# This script will scan all devices from a certain OU, an will disable them after 50 day of inactivity (Last logon Time Stamp)
# 9 Months after it was flagged as inactive, it will then be deleted with the creation of a log entry
#
# Creator: Jan Niederhauser, WPP

# Import the required modules
Import-Module ActiveDirectory

# Variables
$OUs = 'OU=AdmMagnt-Test,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net'
[int]$timeToDisable = #[Days]
[int]$timeToDelete = #[Days]
$logLocation = # Created if non existant
$logName = # Created if non existant
$savedAttributes = # Defines which Attributes are saved
$exceptionGroups = "OT-Group", "Dummy-Test"
#$descriptionWritten = "## $disMonth_del $delMonth"

# Import all devices with last logon time stamp > $timeToDisable Days
function importDevices {
    param (
        $OU,
        $exceptionGroups,
        $timeToDisable,
        $type # Disabled or Deleted
    )

    if ($type -eq "Disabled") {
        $deviceList =  Get-ADComputer -Filter * -SearchBase $OU -Properties accountExpires | Where-Object { $_.accountExpires -ne 0 -and $_.memberof -notin $exceptionGroups}
    }
    elseif ($type -eq "Default") {
        $deviceList =  Get-ADComputer -Filter * -SearchBase $OU -Properties accountExpires | Where-Object { $_.accountExpires -eq 0 }
    }
    else {
        # log
    }

    return $deviceList
}

# Check last logon timestamp of all devices

# Save devices > 50 days offline to collection

# Check if devices are disabled

# Check if devices disabled for more than 9 Months

# Export Information to Excel

# Delete device from AD

# Main
foreach ($OU in $OUs) {
    $nonDisabledDevices = importDevices -OU $OU -exceptionGroups $exceptionGroups -timeToDisable $timeToDisable -type "Default"
    $disabledDevices = importDevices -OU $OU -exceptionGroups $exceptionGroups -timeToDisable $timeToDisable -type "Disabled"
}
