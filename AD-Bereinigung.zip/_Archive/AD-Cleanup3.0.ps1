# Import the necessary modules
Import-Module ActiveDirectory

# Set the variables
$readOnly = $true # Set to $true to run the script in read-only mode
$OUs = @("OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the OUs to search @("OU=OU1,DC=domain,DC=com", "OU=OU2,DC=domain,DC=com") - "OU=AD-Test,OU=AdmMagnt-Test,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net"
$disableDate = (Get-Date).AddDays(-50) # Set the disable date to 50 days ago
[int]$deletionDelay = 10
$deletionDate = (Get-Date).AddMonths($deletionDelay) # Set the deletion date to 10 months from now
$excludedADGroups = @("CN=ETACH-OT-Devices,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net", "CN=ETACH-OT-Candidates,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net", "CN=ETACH-Aktive-mGuard,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the AD groups to exclude from being disabled
$excludedDivisionValues = @("6808") # Specify the division values to exclude from being disabled,   ,"Value2"
$csvFilePath = "C:\temp\File.csv" # Specify the path to the CSV file
$logFilePath = "C:\temp\" # Specify the path to the log file
$logFileName = "AD-Cleanup_" + (get-date -Format dd_MM_yyyy)
$logFile = $logFilePath + $logFileName + ".log"

# Start logging all actions to a log file
Start-Transcript -Path $logFile

# Create a function to check if a device should be excluded
function ShouldExcludeDevice($device) {
    # Check if the device is a member of any of the excluded AD groups
    foreach ($group in $excludedADGroups) {
        if ((Get-ADComputer $device -Properties MemberOf).MemberOf -contains $group) {
            return $true
        }
    }

    # Check if the device has an excluded division value
    if ($excludedDivisionValues -contains (Get-ADComputer $device -Properties division | Select-Object -ExpandProperty division)) {
        return $true
    }

    return $false
}

# Create a function to export data to a CSV file
function ExportToCSV($data) {
    # Check if the CSV file exists
    if (!(Test-Path $csvFilePath)) {
        # Create a new CSV file

        # Add the headers
        $headers = $data.Keys -join ","
        Add-Content -Path $csvFilePath -Value $headers
    }

    # Add the data
    $values = $data.Values -join ","
    Add-Content -Path $csvFilePath -Value $values

    Write-Host "Data exported to CSV: $values"
}

# Search for devices in the specified OUs
foreach ($OU in ($OUs)) {
    $ADList = Get-ADComputer -Filter * -SearchBase $OU
    foreach ($comp in $ADList) {
        # Check if the device should be excluded
        if (ShouldExcludeDevice $comp) {
            continue;
        }

        # Get the device's last logon timestamp
        $lastLogonTimestampValue = (Get-ADComputer $comp.SamAccountName -Properties lastLogonTimestamp | Select-Object -ExpandProperty lastLogonTimestamp)

        if ($lastLogonTimestampValue -ne $null) {
            # Convert the last logon timestamp to a DateTime object
            [DateTime]$lastLogonTimestamp = [DateTime]::FromFileTime($lastLogonTimestampValue)
        }
        else {
            Write-Output ("No last logon timestamp '" + $comp.SamAccountName + "'")
            continue;
        }

        # Get the device's last logon timestamp and convert it to a DateTime object
        [DateTime]$lastLogonTimestamp = [DateTime]::FromFileTime((Get-ADComputer $comp.SamAccountName -Properties lastLogonTimestamp | Select-Object -ExpandProperty lastLogonTimestamp))

        if ($lastLogonTimestamp -lt ($disableDate)) {
            # The device's last logon timestamp is older than 50 days

            # Check if there is an existing comment with a marked date of deletion
            [string]$comment = (Get-ADComputer $comp.SamAccountName -Properties Description | Select-Object -ExpandProperty Description)
            if ($comment -match "\[d\] \d{2}\.\d{4}_\d{2}\.\d{4}_#") {
                # There is an existing comment with a marked date of deletion

                # Get the marked date of deletion from the comment
                [string]$markedDeletionDate = ($comment.Substring(($comment.IndexOf("[d]") + 12), 7))
                [int]$markedDeletionMonth = [int]$markedDeletionDate.Substring(0, 2)
                [int]$markedDeletionYear = [int]$markedDeletionDate.Substring(3, 4)

                # Check if the current month and year is equal to or later than the marked date of deletion
                if ((Get-Date).Year -gt $markedDeletionYear -or ((Get-Date).Year -eq $markedDeletionYear -and (Get-Date).Month -ge $markedDeletionMonth)) {
                    # The current month and year is equal to or later than the marked date of deletion

                    # Export the BitLocker key, LAPS password, client name, and deletion date to a CSV file
                    $bitLockerKey = (Get-ADObject -Filter 'objectClass -eq "msFVE-RecoveryInformation"' -SearchBase $comp.DistinguishedName -Properties msFVE-RecoveryPassword | Select-Object -ExpandProperty msFVE-RecoveryPassword)
                    $lapsPassword = (Get-ADComputer $comp.SamAccountName -Properties ms-Mcs-AdmPwd | Select-Object -ExpandProperty ms-Mcs-AdmPwd)
                    $clientName = $comp.Name
                    $deletionDate = Get-Date
                    $data = @{
                        "BitLocker Key" = $bitLockerKey;
                        "LAPS Password" = $lapsPassword;
                        "Client Name"   = $clientName;
                        "Deletion Date" = $deletionDate;
                    }
                    ExportToCSV $data

                    if (!$readOnly) {
                        # Remove the device from AD
                        Remove-ADComputer $comp.SamAccountName -Confirm:$false
                    }

                    # Log the deletion action
                    Write-Output ("Deleted device '" + $comp.SamAccountName + "'")
                }
            }
            else {
                # There is no existing comment with a marked date of deletion
                # Disable the device
                # Create a comment on the device before the existing comment following the specified pattern
                [string]$disableMonthYear = (Get-Date).ToString("MM.yyyy")
                [string]$deletionMonthYear = (Get-Date).AddMonths($deletionDelay).ToString("MM.yyyy")
                [string]$newComment = "[d] " + ($disableMonthYear) + "_" + ($deletionMonthYear) + "_#"
                $fullComment = ($newComment + " " + (Get-ADComputer $comp.SamAccountName -Properties Description | Select-Object -ExpandProperty Description))

                if (!$readOnly) {
                    Set-ADComputer $comp.SamAccountName -Description $fullComment

                    # Disable the device in AD
                    Disable-ADAccount $comp.SamAccountName
                }

                # Log the disable action
                Write-Output ("Disabled device '" + $comp.SamAccountName + "'" + " $fullComment set as description")
            }
        }
        else {
            # The device's last logon timestamp is not older than 50 days

            # Check if there is an existing comment with a marked date of deletion
            [string]$comment = (Get-ADComputer $comp.SamAccountName -Properties Description | Select-Object -ExpandProperty Description)
            if ($comment -match "\[d\] \d{2}\.\d{4}_\d{2}\.\d{4}_#") {
                # There is an existing comment with a marked date of deletion

                if (!$readOnly) {
                    # Remove the created comment between the symbol [d] and _#
                    [int]$startIndex = ($comment.IndexOf("[d]"))
                    [int]$endIndex = ($comment.IndexOf("_#") + 2)
                    Set-ADComputer $comp.SamAccountName -Description ($comment.Remove($startIndex, ($endIndex - $startIndex)))
                }

                # Log the removal action
                Write-Output ("Removed comment from device '" + $comp.SamAccountName + "'")
            }
        }
    }
}

# Stop logging all actions to a log file
Stop-Transcript