# AD-Bereinigung automatisieren

## Overview

The "AD-Bereinigung automatisieren" project is designed to automate the cleanup of Active Directory (AD) objects. This script helps in identifying and managing inactive or obsolete computer accounts in Active Directory, ensuring that the directory remains clean and up-to-date.

## Features

- Identify inactive computer accounts based on the last logon timestamp.
- Disable or delete computer accounts that have been inactive for a specified period.
- Exclude certain accounts based on patterns ([x]), AD-Group memberships or divisions (cost center).
- Export results of deleted devices to a CSV file for reporting and auditing purposes.
- Run in read-only mode to simulate actions without making changes.
- Send summary emails after the cleanup operation.
- Send error emails if an error occurs during the cleanup operation.

## Prerequisites

- Windows PowerShell 5.1 or later.
- Active Directory module for Windows PowerShell.

## Installation

1. Copy the code to your host where the code will be executed.

2. Navigate to the project directory:
    ```bs
    cd C:\Temp\AD-Bereinigung-automatisieren
    ```

3. Install the required PowerShell modules:
    ```powershell
    Install-Module -Name ActiveDirectory -Force
    ```

## Usage

1. Edit the variables in the script to your liking:
```powershell
$OUs = @("OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the OUs to search @("OU=OU1,DC=domain,DC=com", "OU=OU2,DC=domain,DC=com") - "OU=AD-Test,OU=AdmMagnt-Test,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net"
$ADGroups = @("CN=ETACH-BS-AD-Test,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the AD groups to search if used instead of OU @("CN=Group1,OU=Groups,DC=domain,DC=com", "CN=Group2,OU=Groups,DC=domain,DC=com")
$disableDate = (Get-Date).AddDays(-50) # Set the disable date to 50 days ago
[int]$deletionDelay = 10 # Months until deleted
$deletionDate = (Get-Date).AddMonths($deletionDelay) # Set the deletion date to 10 months from now
$excludedADGroups = @("CN=ETACH-OT-Devices,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net", "CN=ETACH-OT-Candidates,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net", "CN=ETACH-Aktive-mGuard,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the AD groups to exclude from being disabled
$excludedDivisionValues = @("6808") # Specify the division values to exclude from being disabled
$excludedPatternsInComment = @("[x]") # Specify the patterns in comment to exclude from being disabled -> @("[x]", "pattern2", "pattern3")
```

2. Open PowerShell as the account with the necessary permissions, and call the script with the parameters as needed:
```powershell
[bool]$dummyRun = $false, # Set to $true to run the script in test mode with dummy data
[bool]$useAdGroup = $false, # Set to $true to use AD groups instead of OUs
[bool]$enableMetrics = $true, # Set to $true to enable metrics for the cleanup operation
[bool]$readOnlyMode = $true, # Set to $true to run the script in read-only mode
[bool]$sendMail = $true, # Set to $true to send a summary email after the cleanup operation
[bool]$adgroupAnalytics = $true, # Set to $true to enable adgroup analytics
[bool]$sendMailError = $true # Set to $true to send an error email if an error occurs during the cleanup operation
```

3. Run the script with your parameters:
```powershell
.\AD-Cleanup.ps1 -dummyRun $false -useAdGroup $false -readOnlyMode $true -enableMetrics $false -sendMail $true -adgroupAnalytics $true -sendMailError $true
```

4. Review the output and CSV reports generated in the specified directory.

## Contact

The script was developed by Jan Niederhauser from the Digital Infrastructure Team.
For any questions or support, please contact [digiinfra@eta.ch](mailto:digiinfra@eta.ch).