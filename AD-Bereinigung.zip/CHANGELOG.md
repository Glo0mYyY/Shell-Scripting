# Changelog

All notable changes to this project will be documented in this file.

## [1.2.0] - 06.01.2025
### Added
- Added email notifications for errors during the cleanup operation.
- Added 3 retries when Get-ADComputer fails

## [1.1.1] - 16.12.2024
### Fixed
- Script threw an error when setting the description to ""

## [1.1.0] - 15.11.2024
### Added
- Added an AD-Group Analytics function

### Fixed
- Improved logic for no LLTS devices
