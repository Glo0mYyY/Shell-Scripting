<#
.SYNOPSIS
Creates a summary of the AD cleanup metrics.

.DESCRIPTION
The New-Summary function is used to generate a summary of the metrics for an AD cleanup operation. It takes various parameters representing different metrics and exports the summary to a CSV file.

.PARAMETER amountDeleted
The number of devices that were deleted during the cleanup operation.

.PARAMETER amountDisabled
The number of devices that were already disabled before the cleanup operation.

.PARAMETER amountEnabled
The number of devices where the comment was removed during the cleanup operation.

.PARAMETER amountNoTimestamp
The number of devices that did not have a timestamp during the cleanup operation.

.PARAMETER amountCommentSet
The number of devices where the comment was already set before the cleanup operation.

.PARAMETER amountExcludedAdGroup
The number of devices that were excluded from the cleanup operation due to AD group membership.

.PARAMETER amountExcludedDivision
The number of devices that were excluded from the cleanup operation due to division.

.PARAMETER amountExcludedPattern
The number of devices that were excluded from the cleanup operation due to a pattern match.

.PARAMETER amountError
The number of devices where an error occurred during the cleanup operation.

.PARAMETER amountActive
The number of devices that were active during the cleanup operation.

.PARAMETER filePath
The path to the file where the summary will be written.

.EXAMPLE
New-Summary -amountDeleted 10 -amountDisabled 5 -amountEnabled 3 -amountNoTimestamp 2 -amountCommentSet 7 -amountExcludedAdGroup 4 -amountExcludedDivision 1 -amountExcludedPattern 6 -amountError 2 -amountActive 15 -filePath "C:\Path\To\Summary.csv"
#>

function New-Summary {
    param (
        [int]$amountDeleted,
        [int]$amountDisabled,
        [int]$amountEnabled,
        [int]$amountNoTimestamp,
        [int]$amountCommentSet,
        [int]$amountExcludedAdGroup,
        [int]$amountExcludedDivision,
        [int]$amountExcludedPattern,
        [int]$amountError,
        [int]$amountActive,
        [string]$filePath
    )

    # Create a hashtable with the date as the first key
    $data = @(
        [pscustomobject]@{
            'Date'                = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
            'Deleted'             = $amountDeleted
            'Disabled'            = $amountDisabled
            'Enabled'             = $amountEnabled
            'No Timestamp'        = $amountNoTimestamp
            'Comment already Set' = $amountCommentSet
            'Excluded AD Group'   = $amountExcludedAdGroup
            'Excluded Division'   = $amountExcludedDivision
            'Excluded Pattern'    = $amountExcludedPattern
            'Error'               = $amountError
            'Active'              = $amountActive
        }
    )

    # Check if the file exists
    if (Test-Path $filePath) {
        # If file exists, append the data (no headers)
        $data | Export-Csv -Path $filePath -Append -NoTypeInformation
    }
    else {
        # If file does not exist, create a new one with headers
        $data | Export-Csv -Path $filePath -NoTypeInformation
    }

    Write-Output "Summary written to $filePath"
    return $data
}

# Example usage of the function
#New-Summary -amountDeleted (Get-Random -Minimum 10 -Maximum 101) -amountDisabled (Get-Random -Minimum 10 -Maximum 101) -amountEnabled (Get-Random -Minimum 10 -Maximum 101) -amountNoTimestamp (Get-Random -Minimum 10 -Maximum 101) -amountCommentSet (Get-Random -Minimum 10 -Maximum 101) -amountExcludedAdGroup (Get-Random -Minimum 10 -Maximum 101) -amountExcludedDivision (Get-Random -Minimum 10 -Maximum 101) -amountExcludedPattern (Get-Random -Minimum 10 -Maximum 101) -amountError (Get-Random -Minimum 10 -Maximum 101) -amountActive (Get-Random -Minimum 10 -Maximum 101) -filePath 'C:\Temp\Summary.csv'

# SIG # Begin signature block
# MIIQ9QYJKoZIhvcNAQcCoIIQ5jCCEOICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA+buEAP8vBzxDu
# P6xvEK+KMLN3LRWWUVt72RkqrRNptaCCDjMwggbqMIIE0qADAgECAhMeAAAAlAjw
# deh5XIJjAAAAAACUMA0GCSqGSIb3DQEBCwUAME8xCzAJBgNVBAYTAkNIMR0wGwYD
# VQQKExRUaGUgU3dhdGNoIEdyb3VwIEx0ZDEhMB8GA1UEAxMYU3dhdGNoIEdyb3Vw
# IFN5c3RlbSBDQSAxMB4XDTE2MDcyODExNDMyMloXDTI2MDcyNjExNDMyMlowaTEL
# MAkGA1UEBhMCQ0gxLDAqBgNVBAoTI0VUQSBTQSBNYW51ZmFjdHVyZSBIb3Jsb2dl
# cmUgU3Vpc3NlMSwwKgYDVQQDEyNFVEEgU0EgTWFudWZhY3R1cmUgSG9ybG9nZXJl
# IFN1aXNzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALCaXuMxl+6o
# EqiCctaFpBEq7jud9VDOnqHbShjqEHEYP7ove3opkeGcWzHyl7JdIEfPageeqGW3
# BLhSHN63kC/KZiTtQ4XSJjSsN4KiQwZsPtk3kHQAJnTsT5oOFJXlMYYmKqdU9uZ2
# ar8USjYB0XdCvXzCZRRdE14pPbGAGVVD9AsdWVMOjMvq7vKWGrfSRrVUsw1qlnYQ
# 3A5NOQ7pjsrXffEUnrXUq+1QYUOqeFfWWcm8zZPY+jkt/T8b4GZxu1tYDpUCFFfH
# CAOl/rn2ezO+HFI2q2ZZY/MWL19T0UzjJEFkUaBShBMGlqXm7w6/4OUfBWair2sS
# 0k+NtLvqircCAwDk/aOCAqMwggKfMB0GA1UdDgQWBBR9eUv4jpidbNOnZKKl4xmU
# boizmjAfBgNVHSMEGDAWgBS9E59YiOJVatuTbc0Ugk1Jxuz2UDCBxAYDVR0fBIG8
# MIG5MIG2oIGzoIGwhjdodHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dh
# dGNoR3JvdXBTeXN0ZW1DQTEuY3JshnVsZGFwOi8vL0NOPVN3YXRjaEdyb3VwU3lz
# dGVtQ0ExLENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2
# aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPXN3YXRjaGdyb3VwLERDPXJvb3QwgYEG
# CCsGAQUFBwEBBHUwczBDBggrBgEFBQcwAoY3aHR0cDovL3BraS5zd2F0Y2hncm91
# cC5uZXQvYWlhL1N3YXRjaEdyb3VwU3lzdGVtQ0ExLmNydDAsBggrBgEFBQcwAYYg
# aHR0cDovL29jc3Auc3dhdGNoZ3JvdXAubmV0L29jc3AwPgYJKwYBBAGCNxUHBDEw
# LwYnKwYBBAGCNxUIgayEYYTg3yOC5Z0yhZvEUYGt5R+BaoPO7CGGxYltAgFkAgEQ
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAMBgNVHRMBAf8EAjAA
# MIGEBgNVHSAEfTB7MDwGCysGAQQBga1jAQECMC0wKwYIKwYBBQUHAgEWH2h0dHA6
# Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2NwcwAwOwYKKwYBBAGBrWMCBDAtMCsGCCsG
# AQUFBwIBFh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMBsGCSsGAQQB
# gjcVCgQOMAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggIBADuWU1pXOXUt
# pPBDltPRhQO4SCIIW7jMuS7xcd1Azh7KHIhWw1ZDR3rjypiFwRwUfX/3KHRIVWKn
# jZCiFcaywf1MtJqFfpB5Ewjf84vOk8AW18fFOX9CoTKVQsszHY6Dr3+XVW8CV0s3
# /YAuHLd/zdkQ4i5GvROrX2Mt2l+IQ6yM688pqI3KNcvzF2lElGLtTII3Wouk0mYs
# VtsKRtvlPO8qiJoQlKhJo3MTdUgB4kxSDaDcofvWy51wAVQD7kjENXjgyYK1FGw4
# 6aTNvWg0rxwGt52J8TreXSKAxRjcg9hrbOdu81b3rfaV8MJKWLgA8iLn5JmBIfBt
# zj92o2QaVe5nCO1LDq51vxSHpiqxHgHaEDAOdQNy4ImF+grt63S/IWSBuHJiEbUl
# FgL+OMiSHHwI8Y3NopYrVCAIw1FVx2JyXxn5Hd0bqRVslS7Ao1jWHDbWXvRE9LKG
# Xa+HeFhfh8e7HCGiAcaMTjf0z9/ELELWCUVkxmta/xjILyDK3DFAmrNdKiC5/vYt
# aNVZ4g8Z/C3JeIdsnNzQEI5TODyu4jmQ2QgDvbN97DvHYw8mGX7KT9KbiYTY7tHR
# K2r+b+EbjUMnRf0BtZY9C82b4vKUCC8U6ZtVV4HYE/uEOF3x184LOjaNlHFvOJEf
# zhgahrEc3/mFHN/WEbCQ+7u4zPAyCfrjMIIHQTCCBSmgAwIBAgITEQAAAASHw0YH
# OuspOwAAAAAABDANBgkqhkiG9w0BAQsFADBNMQswCQYDVQQGEwJDSDEdMBsGA1UE
# ChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxHzAdBgNVBAMTFlN3YXRjaCBHcm91cCBS
# b290IENBIDEwHhcNMTYwNTA5MTIwNTU1WhcNNDEwNTAzMTIwNTU1WjBPMQswCQYD
# VQQGEwJDSDEdMBsGA1UEChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxITAfBgNVBAMT
# GFN3YXRjaCBHcm91cCBTeXN0ZW0gQ0EgMTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAOxciJUVJemY6TixhlEqniQwIZSDeYuQo45nNeRNWISMI7scaG4Z
# fdhLLwFm0x0vRF50b0OBKYkcnsV/t0eaZn3PZvzbLyLNqWeQ5d3aQeYw8iFfoPAe
# HYp1vzYWs98cDxxFwebwP5I+iBueUWSWC4DgKc/vYWfZSMexaKrLnSYMnU4PsCgz
# bEt+NUkGGR68pWgbaX2dE5jplW5OiDltKElVzwLLcWjZD7LC+4nY+u2woMct0kNB
# YD5k9QA0nVRHE7GPRRQYsYF1i3CRmIHaOqS+RjvguUmkImvbDbyBarjEJnFcsK+c
# XKPaVHbtJU6rByh1q4DVcczZ55wKU6LGGZTUOXNEgMm/vamSfw4eIrIeDtGTY0hc
# yhznSENFUgN7/8qqn5t1giOt4B1iMU8cOAv0orhgf0VHQVRxYJkIq0AnsSJkhfGy
# geS/5x/qAFUBmbseuw8GSTWWe0gj31YfuTbXLNu7DrjffGNgxbBR92iDs7y14rab
# kVrjayluVhJRp0ou4Wkg6b7gEhISS5DMgdPffsCNikhc7MmfYLU5AurG87YYQa5l
# Vtzo5pGis768hnfShJrHdKQockNtG+3KoHP0LEGBXvgio71MB8MhE1zwyWkqaXQq
# itmtgpDe+J5twOfz5zqcfRbQB3Dp5WBoevoUSe2c5Nn+USgsx1WMcYxPAgMBAAGj
# ggIWMIICEjAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUvROfWIjiVWrbk23N
# FIJNScbs9lAwRwYDVR0gBEAwPjA8BgsrBgEEAYGtYwEBAjAtMCsGCCsGAQUFBwIB
# Fh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMD4GCSsGAQQBgjcVBwQx
# MC8GJysGAQQBgjcVCIGshGGE4N8jguWdMoWbxFGBreUfgWqCypEWgqrlSQIBZAIB
# BTALBgNVHQ8EBAMCAYYwEgYDVR0TAQH/BAgwBgEB/wIBATAfBgNVHSMEGDAWgBQX
# 9m1ySznuzoXkg8QK2jhquzF3BTCBwAYDVR0fBIG4MIG1MIGyoIGvoIGshjVodHRw
# Oi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dhdGNoR3JvdXBSb290Q0ExLmNy
# bIZzbGRhcDovLy9DTj1Td2F0Y2hHcm91cFJvb3RDQTEsQ049Q0RQLENOPVB1Ymxp
# YyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24s
# REM9c3dhdGNoZ3JvdXAsREM9cm9vdDBRBggrBgEFBQcBAQRFMEMwQQYIKwYBBQUH
# MAKGNWh0dHA6Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2FpYS9Td2F0Y2hHcm91cFJv
# b3RDQTEuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQAN8/Vx9xrim7iEslVm9FEJ7hZT
# xHfPzQO9p06uClm5MID139O/GSy0U0Aa0anWzi9lkMRP+cmc3KY+SvtI1GUlSfnR
# pKVTxqKuX1BbmPDThFZStSbsTjYN4OZsJ4F+Ng+6ZDD3wwPlXPJ1Ht6aIZ3hgrvl
# sZrL2qHz/VOo2TCRmDOe6tr4KjJL3Ey+qFvaHmhQ1XNNgVA2oLxB5ACE9l3RHQEv
# oMDirdSm9COzvmlCAGXnDYfGJRuVqVpNvYIgQ0ipAympYqyL6Pvx1c8ProwKpXSs
# cZ0phJA/tiBcVplHH9ZZSFM2q/dH0gcqwM8OCahbdzu+Ht3B2Z14sKIaFi+UF8F5
# EC+c6wf0azUOuO+sLXpDHo1Vz3GO77xhj7pfzcvuxcru8IznTZwlFDujbCVUbh51
# rcyKMMQv9taqryi0lAuCgDU6p4k0iaGPxb+dXnBhYrM46IoSBK0tUz/w5ojk1i++
# cqVZI9XfyYrJYTAqfnxhNEldEYYPxCzni+dM2D+8TiCsC8Q89i3kT8HQkUkH7/6M
# r0keb7OVahtvl1XM+HiM60TEWXXH7dYlU6FgfhaoHSjwCr32gDTY9clb5UQgPuMQ
# DPpuk1AFoZD7sh/lUi0lPefEHNouWbgsaTiZnso8s/oJwJeG3nPwkXh9z9FSHcd9
# cvg8piR5mjUXKrlmfzGCAhgwggIUAgEBMGYwTzELMAkGA1UEBhMCQ0gxHTAbBgNV
# BAoTFFRoZSBTd2F0Y2ggR3JvdXAgTHRkMSEwHwYDVQQDExhTd2F0Y2ggR3JvdXAg
# U3lzdGVtIENBIDECEx4AAACUCPB16HlcgmMAAAAAAJQwDQYJYIZIAWUDBAIBBQCg
# gYQwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0B
# CQQxIgQgl9hiLnriLbPJWoBvWcxBLW2I5byYaPhD88aduZsOqr0wDQYJKoZIhvcN
# AQEBBQAEggEAnsSmvuVv9Y28GbiTXNn/+lYiUaI8ZDWuxFxfix2sVU8al3NwFUW+
# 4VilKzTIJJ2TF94fkmL14wQO6RBL5UV0VsqgNfNi15oniyKiYqw/reficXf9dEZ+
# z8MpojF3x+xVVohd+GwRpy4MN61uuAYN341Qj3SwuHeUYu9CwNkXGl4GvFAYpTkw
# tmhWopXiyAaRwipgpv8SIGsakUCDEcpBDPRJCCDnRJkBcrq/hogKaY1dKPber78e
# JT4Wtbt8xjRVoN8wJSiDh16a3sc0yHIfno/5W6F+xSckNDXa9TvGMRlG/ig7rvMI
# FKZ2RGMSBOuvr8TC4T9steR6gDdImcrcxw==
# SIG # End signature block
