# Define dummy data
$global:dummyData = @(
    # Gerät ohne LLTS
    [pscustomobject]@{ Name = "TestComputer1"; SamAccountName = "TestComputer1"; lastLogonTimestamp = 0; Description = ""; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer1,OU=Computers,DC=example,DC=com"; expectedResult = "No Timestamp" },
    
    # Gerät mit LLTS < 50 Tage ohne Kommentar
    [pscustomobject]@{ Name = "TestComputer2"; SamAccountName = "TestComputer2"; lastLogonTimestamp = (Get-Date).AddDays(-50).ToFileTime(); Description = ""; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer2,OU=Computers,DC=example,DC=com"; expectedResult = "Nothing" },
    
    # Gerät mit LLTS < 50 Tage und Kommentar das es gelöscht werden soll im aktuellen Monat
    [pscustomobject]@{ Name = "TestComputer3"; SamAccountName = "TestComputer3"; lastLogonTimestamp = (Get-Date).AddDays(-49).ToFileTime(); Description = "blablabla[d] 09.2024_09.2024_#TestTest"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer3,OU=Computers,DC=example,DC=com"; expectedResult = "Comment Removed" },
    
    # Gerät mit LLTS < 50 Tage und Kommentar das es gelöscht werden soll im vergangenen Monat
    [pscustomobject]@{ Name = "TestComputer4"; SamAccountName = "TestComputer4"; lastLogonTimestamp = (Get-Date).AddDays(-0).ToFileTime(); Description = "hfsdhfadsfl hjds asdf[d] 09.2024_08.2024_#Hehhehe"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer4,OU=Computers,DC=example,DC=com"; expectedResult = "Comment Removed" },
    
    # Gerät mit LLTS < 50 Tage und Kommentar das es gelöscht werden soll im nächsten Monat
    [pscustomobject]@{ Name = "TestComputer5"; SamAccountName = "TestComputer5"; lastLogonTimestamp = (Get-Date).AddDays(-40).ToFileTime(); Description = "jdsfkjsdlf[d] 09.2024_10.2024_#HalliHalloTest"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer5,OU=Computers,DC=example,DC=com"; expectedResult = "Comment Removed" },
    
    # Gerät mit LLTS > 50 Tage ohne Kommentar
    [pscustomobject]@{ Name = "TestComputer6"; SamAccountName = "TestComputer6"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = ""; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer6,OU=Computers,DC=example,DC=com"; expectedResult = "Disabled" },
    
    # Gerät mit LLTS > 50 Tage mit informativem Kommentar
    [pscustomobject]@{ Name = "TestComputer6.1"; SamAccountName = "TestComputer6.1"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = "Test Gerät von Jan"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer6.1,OU=Computers,DC=example,DC=com"; expectedResult = "Disabled mit bestehendem Kommentar" },
    
    # Gerät mit LLTS > 50 Tage und Kommentar das es gelöscht werden soll im aktuellen Monat
    [pscustomobject]@{ Name = "TestComputer7"; SamAccountName = "TestComputer7"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = "[d] 09.2024_09.2024_#TestTest"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer7,OU=Computers,DC=example,DC=com"; expectedResult = "Deleted" },
    
    # Gerät mit LLTS > 50 Tage und Kommentar das es gelöscht werden soll im vergangenen Monat oder später
    [pscustomobject]@{ Name = "TestComputer8"; SamAccountName = "TestComputer8"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = "[d] 09.2024_08.2024_#Hehhehe"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer8,OU=Computers,DC=example,DC=com"; expectedResult = "Deleted" },
    
    # Gerät mit LLTS > 50 Tage und Kommentar das es gelöscht werden soll im nächsten Monat
    [pscustomobject]@{ Name = "TestComputer9"; SamAccountName = "TestComputer9"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = "[d] 09.2024_10.2024_#HalliHalloTest"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer9,OU=Computers,DC=example,DC=com"; expectedResult = "Not Deleted" },
    
    # Geräte mit [x] im Kommentar
    [pscustomobject]@{ Name = "TestComputer10"; SamAccountName = "TestComputer10"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = "[x]"; Division = ""; MemberOf = @(); DistinguishedName = "CN=TestComputer10,OU=Computers,DC=example,DC=com"; expectedResult = "Excluded" },
    
    # Geräte mit definierten AD-Gruppen als Exception
    [pscustomobject]@{ Name = "TestComputer11"; SamAccountName = "TestComputer11"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = ""; Division = ""; MemberOf = @("CN=ETACH-OT-Devices,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net"); DistinguishedName = "CN=TestComputer11,OU=Computers,DC=example,DC=com"; expectedResult = "Excluded" },
    
    # Geräte mit definierter KST 6808
    [pscustomobject]@{ Name = "TestComputer12"; SamAccountName = "TestComputer12"; lastLogonTimestamp = (Get-Date).AddDays(-60).ToFileTime(); Description = ""; Division = "6808"; MemberOf = @(); DistinguishedName = "CN=TestComputer12,OU=Computers,DC=example,DC=com"; expectedResult = "Excluded" }
)

# SIG # Begin signature block
# MIIQ9QYJKoZIhvcNAQcCoIIQ5jCCEOICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC++l8mxRYEToKa
# AQSdtw2WmHTQr+DofxWwvWjTnnG3JqCCDjMwggbqMIIE0qADAgECAhMeAAAAlAjw
# deh5XIJjAAAAAACUMA0GCSqGSIb3DQEBCwUAME8xCzAJBgNVBAYTAkNIMR0wGwYD
# VQQKExRUaGUgU3dhdGNoIEdyb3VwIEx0ZDEhMB8GA1UEAxMYU3dhdGNoIEdyb3Vw
# IFN5c3RlbSBDQSAxMB4XDTE2MDcyODExNDMyMloXDTI2MDcyNjExNDMyMlowaTEL
# MAkGA1UEBhMCQ0gxLDAqBgNVBAoTI0VUQSBTQSBNYW51ZmFjdHVyZSBIb3Jsb2dl
# cmUgU3Vpc3NlMSwwKgYDVQQDEyNFVEEgU0EgTWFudWZhY3R1cmUgSG9ybG9nZXJl
# IFN1aXNzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALCaXuMxl+6o
# EqiCctaFpBEq7jud9VDOnqHbShjqEHEYP7ove3opkeGcWzHyl7JdIEfPageeqGW3
# BLhSHN63kC/KZiTtQ4XSJjSsN4KiQwZsPtk3kHQAJnTsT5oOFJXlMYYmKqdU9uZ2
# ar8USjYB0XdCvXzCZRRdE14pPbGAGVVD9AsdWVMOjMvq7vKWGrfSRrVUsw1qlnYQ
# 3A5NOQ7pjsrXffEUnrXUq+1QYUOqeFfWWcm8zZPY+jkt/T8b4GZxu1tYDpUCFFfH
# CAOl/rn2ezO+HFI2q2ZZY/MWL19T0UzjJEFkUaBShBMGlqXm7w6/4OUfBWair2sS
# 0k+NtLvqircCAwDk/aOCAqMwggKfMB0GA1UdDgQWBBR9eUv4jpidbNOnZKKl4xmU
# boizmjAfBgNVHSMEGDAWgBS9E59YiOJVatuTbc0Ugk1Jxuz2UDCBxAYDVR0fBIG8
# MIG5MIG2oIGzoIGwhjdodHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dh
# dGNoR3JvdXBTeXN0ZW1DQTEuY3JshnVsZGFwOi8vL0NOPVN3YXRjaEdyb3VwU3lz
# dGVtQ0ExLENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2
# aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPXN3YXRjaGdyb3VwLERDPXJvb3QwgYEG
# CCsGAQUFBwEBBHUwczBDBggrBgEFBQcwAoY3aHR0cDovL3BraS5zd2F0Y2hncm91
# cC5uZXQvYWlhL1N3YXRjaEdyb3VwU3lzdGVtQ0ExLmNydDAsBggrBgEFBQcwAYYg
# aHR0cDovL29jc3Auc3dhdGNoZ3JvdXAubmV0L29jc3AwPgYJKwYBBAGCNxUHBDEw
# LwYnKwYBBAGCNxUIgayEYYTg3yOC5Z0yhZvEUYGt5R+BaoPO7CGGxYltAgFkAgEQ
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAMBgNVHRMBAf8EAjAA
# MIGEBgNVHSAEfTB7MDwGCysGAQQBga1jAQECMC0wKwYIKwYBBQUHAgEWH2h0dHA6
# Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2NwcwAwOwYKKwYBBAGBrWMCBDAtMCsGCCsG
# AQUFBwIBFh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMBsGCSsGAQQB
# gjcVCgQOMAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggIBADuWU1pXOXUt
# pPBDltPRhQO4SCIIW7jMuS7xcd1Azh7KHIhWw1ZDR3rjypiFwRwUfX/3KHRIVWKn
# jZCiFcaywf1MtJqFfpB5Ewjf84vOk8AW18fFOX9CoTKVQsszHY6Dr3+XVW8CV0s3
# /YAuHLd/zdkQ4i5GvROrX2Mt2l+IQ6yM688pqI3KNcvzF2lElGLtTII3Wouk0mYs
# VtsKRtvlPO8qiJoQlKhJo3MTdUgB4kxSDaDcofvWy51wAVQD7kjENXjgyYK1FGw4
# 6aTNvWg0rxwGt52J8TreXSKAxRjcg9hrbOdu81b3rfaV8MJKWLgA8iLn5JmBIfBt
# zj92o2QaVe5nCO1LDq51vxSHpiqxHgHaEDAOdQNy4ImF+grt63S/IWSBuHJiEbUl
# FgL+OMiSHHwI8Y3NopYrVCAIw1FVx2JyXxn5Hd0bqRVslS7Ao1jWHDbWXvRE9LKG
# Xa+HeFhfh8e7HCGiAcaMTjf0z9/ELELWCUVkxmta/xjILyDK3DFAmrNdKiC5/vYt
# aNVZ4g8Z/C3JeIdsnNzQEI5TODyu4jmQ2QgDvbN97DvHYw8mGX7KT9KbiYTY7tHR
# K2r+b+EbjUMnRf0BtZY9C82b4vKUCC8U6ZtVV4HYE/uEOF3x184LOjaNlHFvOJEf
# zhgahrEc3/mFHN/WEbCQ+7u4zPAyCfrjMIIHQTCCBSmgAwIBAgITEQAAAASHw0YH
# OuspOwAAAAAABDANBgkqhkiG9w0BAQsFADBNMQswCQYDVQQGEwJDSDEdMBsGA1UE
# ChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxHzAdBgNVBAMTFlN3YXRjaCBHcm91cCBS
# b290IENBIDEwHhcNMTYwNTA5MTIwNTU1WhcNNDEwNTAzMTIwNTU1WjBPMQswCQYD
# VQQGEwJDSDEdMBsGA1UEChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxITAfBgNVBAMT
# GFN3YXRjaCBHcm91cCBTeXN0ZW0gQ0EgMTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAOxciJUVJemY6TixhlEqniQwIZSDeYuQo45nNeRNWISMI7scaG4Z
# fdhLLwFm0x0vRF50b0OBKYkcnsV/t0eaZn3PZvzbLyLNqWeQ5d3aQeYw8iFfoPAe
# HYp1vzYWs98cDxxFwebwP5I+iBueUWSWC4DgKc/vYWfZSMexaKrLnSYMnU4PsCgz
# bEt+NUkGGR68pWgbaX2dE5jplW5OiDltKElVzwLLcWjZD7LC+4nY+u2woMct0kNB
# YD5k9QA0nVRHE7GPRRQYsYF1i3CRmIHaOqS+RjvguUmkImvbDbyBarjEJnFcsK+c
# XKPaVHbtJU6rByh1q4DVcczZ55wKU6LGGZTUOXNEgMm/vamSfw4eIrIeDtGTY0hc
# yhznSENFUgN7/8qqn5t1giOt4B1iMU8cOAv0orhgf0VHQVRxYJkIq0AnsSJkhfGy
# geS/5x/qAFUBmbseuw8GSTWWe0gj31YfuTbXLNu7DrjffGNgxbBR92iDs7y14rab
# kVrjayluVhJRp0ou4Wkg6b7gEhISS5DMgdPffsCNikhc7MmfYLU5AurG87YYQa5l
# Vtzo5pGis768hnfShJrHdKQockNtG+3KoHP0LEGBXvgio71MB8MhE1zwyWkqaXQq
# itmtgpDe+J5twOfz5zqcfRbQB3Dp5WBoevoUSe2c5Nn+USgsx1WMcYxPAgMBAAGj
# ggIWMIICEjAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUvROfWIjiVWrbk23N
# FIJNScbs9lAwRwYDVR0gBEAwPjA8BgsrBgEEAYGtYwEBAjAtMCsGCCsGAQUFBwIB
# Fh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMD4GCSsGAQQBgjcVBwQx
# MC8GJysGAQQBgjcVCIGshGGE4N8jguWdMoWbxFGBreUfgWqCypEWgqrlSQIBZAIB
# BTALBgNVHQ8EBAMCAYYwEgYDVR0TAQH/BAgwBgEB/wIBATAfBgNVHSMEGDAWgBQX
# 9m1ySznuzoXkg8QK2jhquzF3BTCBwAYDVR0fBIG4MIG1MIGyoIGvoIGshjVodHRw
# Oi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dhdGNoR3JvdXBSb290Q0ExLmNy
# bIZzbGRhcDovLy9DTj1Td2F0Y2hHcm91cFJvb3RDQTEsQ049Q0RQLENOPVB1Ymxp
# YyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24s
# REM9c3dhdGNoZ3JvdXAsREM9cm9vdDBRBggrBgEFBQcBAQRFMEMwQQYIKwYBBQUH
# MAKGNWh0dHA6Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2FpYS9Td2F0Y2hHcm91cFJv
# b3RDQTEuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQAN8/Vx9xrim7iEslVm9FEJ7hZT
# xHfPzQO9p06uClm5MID139O/GSy0U0Aa0anWzi9lkMRP+cmc3KY+SvtI1GUlSfnR
# pKVTxqKuX1BbmPDThFZStSbsTjYN4OZsJ4F+Ng+6ZDD3wwPlXPJ1Ht6aIZ3hgrvl
# sZrL2qHz/VOo2TCRmDOe6tr4KjJL3Ey+qFvaHmhQ1XNNgVA2oLxB5ACE9l3RHQEv
# oMDirdSm9COzvmlCAGXnDYfGJRuVqVpNvYIgQ0ipAympYqyL6Pvx1c8ProwKpXSs
# cZ0phJA/tiBcVplHH9ZZSFM2q/dH0gcqwM8OCahbdzu+Ht3B2Z14sKIaFi+UF8F5
# EC+c6wf0azUOuO+sLXpDHo1Vz3GO77xhj7pfzcvuxcru8IznTZwlFDujbCVUbh51
# rcyKMMQv9taqryi0lAuCgDU6p4k0iaGPxb+dXnBhYrM46IoSBK0tUz/w5ojk1i++
# cqVZI9XfyYrJYTAqfnxhNEldEYYPxCzni+dM2D+8TiCsC8Q89i3kT8HQkUkH7/6M
# r0keb7OVahtvl1XM+HiM60TEWXXH7dYlU6FgfhaoHSjwCr32gDTY9clb5UQgPuMQ
# DPpuk1AFoZD7sh/lUi0lPefEHNouWbgsaTiZnso8s/oJwJeG3nPwkXh9z9FSHcd9
# cvg8piR5mjUXKrlmfzGCAhgwggIUAgEBMGYwTzELMAkGA1UEBhMCQ0gxHTAbBgNV
# BAoTFFRoZSBTd2F0Y2ggR3JvdXAgTHRkMSEwHwYDVQQDExhTd2F0Y2ggR3JvdXAg
# U3lzdGVtIENBIDECEx4AAACUCPB16HlcgmMAAAAAAJQwDQYJYIZIAWUDBAIBBQCg
# gYQwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0B
# CQQxIgQgsP670Ty8iu3NNid2pmZ+6OoVCLUj5P4evzPYQ6vS8NYwDQYJKoZIhvcN
# AQEBBQAEggEASQbpjMovKaE4K8/YbwOczjaIK9eoqBQK9kYFOoLoJ5XoqVjh8Ulq
# g6uIBm6y6mI7IjON2Ta69RWNVB9JAcA0M5bfAjnwLgNDyxT/O8uXjrRnWGVDdE1s
# Hf0vV3cLBvHqQqCsi18yANkI/od7JvUCGulpp+3I6mGmshhfjJL3xi935uBOPSg4
# NZOwxjTbRP2lcCMzePEzqPynt/S8852maR8slHwlJoU1Dqor9wSLidmjnvUXbkz0
# LUnIE1yrG2P0c/l2WBkOCkqZcgA0oDpyE0kk8KtxwwByIBQEUIo7e+DANgf3mu2I
# wUpx0IHYnK/fQf0i9MjnFn2iG6ts1voUOw==
# SIG # End signature block
