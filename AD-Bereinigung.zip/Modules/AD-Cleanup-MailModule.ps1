function SendADSummaryMail {
    param (
        [string[]]$mailRecipient,
        [string]$mailSender,
        [string]$mailSubject,
        [string]$mailSmtpServer,
        [array]$deletedDevices,
        [array]$deletedDevicesErrors,
        [string]$mailMode = "delete"
    )

    if ($mailMode -eq "delete") {
        # Define the body of the email with HTML formatting
$body = @"
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        h2 { color: #2F4F4F; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px 12px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f2f2f2; }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <h2>Device Deletion Summary</h2>

    <h3 class='success'>Successfully Deleted Devices:</h3>
    <table>
        <thead>
            <tr>
                <th>Client Name</th>
            </tr>
        </thead>
        <tbody>
            $(if ($deletedDevices) {
                foreach ($device in $deletedDevices) { 
                    "<tr><td>$($device['Client Name'])</td></tr>" 
                }
            } else {
                "<tr><td>No devices deleted.</td></tr>"
            })
        </tbody>
    </table>

    <h3 class='error'>Devices with Errors:</h3>
    <table>
        <thead>
            <tr>
                <th>Client Name</th>
                <th>Error Type</th>
            </tr>
        </thead>
        <tbody>
            $(if ($deletedDevicesErrors) {
                foreach ($device in $deletedDevicesErrors) { 
                    "<tr><td>$($device['Client Name'])</td><td>$($device['Error Type'])</td></tr>" 
                }
            } else {
                "<tr><td colspan='2'>No errors encountered.</td></tr>"
            })
        </tbody>
    </table>
</body>
</html>
"@
    }
    elseif ($mailMode -eq "error") {
        <# Action when this condition is true #>
$body = @"
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; }
        h2 { color: #2F4F4F; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px 12px; border: 1px solid #ddd; text-align: left; }
        th { background-color: #f2f2f2; }
        .error { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <h2>Script Execution Alert</h2>

    <h3 class='error'>Attention Required:</h3>
    <p>One or more devices encountered errors during the script execution. Please review and take necessary action.</p>

</body>
</html>
"@

    }

    try {
        Send-MailMessage -To $mailRecipient -From $mailSender -Subject $mailSubject -SmtpServer $mailSmtpServer -Body $body -BodyAsHtml
    }
    catch {
        Write-Output "Error sending mail: $_"
    }
        
}
# SIG # Begin signature block
# MIIQ9QYJKoZIhvcNAQcCoIIQ5jCCEOICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD00Ue58i43zsp0
# mAcYHkjGOzp5V/o+Zi/pYqW/UraWCaCCDjMwggbqMIIE0qADAgECAhMeAAAAlAjw
# deh5XIJjAAAAAACUMA0GCSqGSIb3DQEBCwUAME8xCzAJBgNVBAYTAkNIMR0wGwYD
# VQQKExRUaGUgU3dhdGNoIEdyb3VwIEx0ZDEhMB8GA1UEAxMYU3dhdGNoIEdyb3Vw
# IFN5c3RlbSBDQSAxMB4XDTE2MDcyODExNDMyMloXDTI2MDcyNjExNDMyMlowaTEL
# MAkGA1UEBhMCQ0gxLDAqBgNVBAoTI0VUQSBTQSBNYW51ZmFjdHVyZSBIb3Jsb2dl
# cmUgU3Vpc3NlMSwwKgYDVQQDEyNFVEEgU0EgTWFudWZhY3R1cmUgSG9ybG9nZXJl
# IFN1aXNzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALCaXuMxl+6o
# EqiCctaFpBEq7jud9VDOnqHbShjqEHEYP7ove3opkeGcWzHyl7JdIEfPageeqGW3
# BLhSHN63kC/KZiTtQ4XSJjSsN4KiQwZsPtk3kHQAJnTsT5oOFJXlMYYmKqdU9uZ2
# ar8USjYB0XdCvXzCZRRdE14pPbGAGVVD9AsdWVMOjMvq7vKWGrfSRrVUsw1qlnYQ
# 3A5NOQ7pjsrXffEUnrXUq+1QYUOqeFfWWcm8zZPY+jkt/T8b4GZxu1tYDpUCFFfH
# CAOl/rn2ezO+HFI2q2ZZY/MWL19T0UzjJEFkUaBShBMGlqXm7w6/4OUfBWair2sS
# 0k+NtLvqircCAwDk/aOCAqMwggKfMB0GA1UdDgQWBBR9eUv4jpidbNOnZKKl4xmU
# boizmjAfBgNVHSMEGDAWgBS9E59YiOJVatuTbc0Ugk1Jxuz2UDCBxAYDVR0fBIG8
# MIG5MIG2oIGzoIGwhjdodHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dh
# dGNoR3JvdXBTeXN0ZW1DQTEuY3JshnVsZGFwOi8vL0NOPVN3YXRjaEdyb3VwU3lz
# dGVtQ0ExLENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2
# aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPXN3YXRjaGdyb3VwLERDPXJvb3QwgYEG
# CCsGAQUFBwEBBHUwczBDBggrBgEFBQcwAoY3aHR0cDovL3BraS5zd2F0Y2hncm91
# cC5uZXQvYWlhL1N3YXRjaEdyb3VwU3lzdGVtQ0ExLmNydDAsBggrBgEFBQcwAYYg
# aHR0cDovL29jc3Auc3dhdGNoZ3JvdXAubmV0L29jc3AwPgYJKwYBBAGCNxUHBDEw
# LwYnKwYBBAGCNxUIgayEYYTg3yOC5Z0yhZvEUYGt5R+BaoPO7CGGxYltAgFkAgEQ
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAMBgNVHRMBAf8EAjAA
# MIGEBgNVHSAEfTB7MDwGCysGAQQBga1jAQECMC0wKwYIKwYBBQUHAgEWH2h0dHA6
# Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2NwcwAwOwYKKwYBBAGBrWMCBDAtMCsGCCsG
# AQUFBwIBFh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMBsGCSsGAQQB
# gjcVCgQOMAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggIBADuWU1pXOXUt
# pPBDltPRhQO4SCIIW7jMuS7xcd1Azh7KHIhWw1ZDR3rjypiFwRwUfX/3KHRIVWKn
# jZCiFcaywf1MtJqFfpB5Ewjf84vOk8AW18fFOX9CoTKVQsszHY6Dr3+XVW8CV0s3
# /YAuHLd/zdkQ4i5GvROrX2Mt2l+IQ6yM688pqI3KNcvzF2lElGLtTII3Wouk0mYs
# VtsKRtvlPO8qiJoQlKhJo3MTdUgB4kxSDaDcofvWy51wAVQD7kjENXjgyYK1FGw4
# 6aTNvWg0rxwGt52J8TreXSKAxRjcg9hrbOdu81b3rfaV8MJKWLgA8iLn5JmBIfBt
# zj92o2QaVe5nCO1LDq51vxSHpiqxHgHaEDAOdQNy4ImF+grt63S/IWSBuHJiEbUl
# FgL+OMiSHHwI8Y3NopYrVCAIw1FVx2JyXxn5Hd0bqRVslS7Ao1jWHDbWXvRE9LKG
# Xa+HeFhfh8e7HCGiAcaMTjf0z9/ELELWCUVkxmta/xjILyDK3DFAmrNdKiC5/vYt
# aNVZ4g8Z/C3JeIdsnNzQEI5TODyu4jmQ2QgDvbN97DvHYw8mGX7KT9KbiYTY7tHR
# K2r+b+EbjUMnRf0BtZY9C82b4vKUCC8U6ZtVV4HYE/uEOF3x184LOjaNlHFvOJEf
# zhgahrEc3/mFHN/WEbCQ+7u4zPAyCfrjMIIHQTCCBSmgAwIBAgITEQAAAASHw0YH
# OuspOwAAAAAABDANBgkqhkiG9w0BAQsFADBNMQswCQYDVQQGEwJDSDEdMBsGA1UE
# ChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxHzAdBgNVBAMTFlN3YXRjaCBHcm91cCBS
# b290IENBIDEwHhcNMTYwNTA5MTIwNTU1WhcNNDEwNTAzMTIwNTU1WjBPMQswCQYD
# VQQGEwJDSDEdMBsGA1UEChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxITAfBgNVBAMT
# GFN3YXRjaCBHcm91cCBTeXN0ZW0gQ0EgMTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAOxciJUVJemY6TixhlEqniQwIZSDeYuQo45nNeRNWISMI7scaG4Z
# fdhLLwFm0x0vRF50b0OBKYkcnsV/t0eaZn3PZvzbLyLNqWeQ5d3aQeYw8iFfoPAe
# HYp1vzYWs98cDxxFwebwP5I+iBueUWSWC4DgKc/vYWfZSMexaKrLnSYMnU4PsCgz
# bEt+NUkGGR68pWgbaX2dE5jplW5OiDltKElVzwLLcWjZD7LC+4nY+u2woMct0kNB
# YD5k9QA0nVRHE7GPRRQYsYF1i3CRmIHaOqS+RjvguUmkImvbDbyBarjEJnFcsK+c
# XKPaVHbtJU6rByh1q4DVcczZ55wKU6LGGZTUOXNEgMm/vamSfw4eIrIeDtGTY0hc
# yhznSENFUgN7/8qqn5t1giOt4B1iMU8cOAv0orhgf0VHQVRxYJkIq0AnsSJkhfGy
# geS/5x/qAFUBmbseuw8GSTWWe0gj31YfuTbXLNu7DrjffGNgxbBR92iDs7y14rab
# kVrjayluVhJRp0ou4Wkg6b7gEhISS5DMgdPffsCNikhc7MmfYLU5AurG87YYQa5l
# Vtzo5pGis768hnfShJrHdKQockNtG+3KoHP0LEGBXvgio71MB8MhE1zwyWkqaXQq
# itmtgpDe+J5twOfz5zqcfRbQB3Dp5WBoevoUSe2c5Nn+USgsx1WMcYxPAgMBAAGj
# ggIWMIICEjAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUvROfWIjiVWrbk23N
# FIJNScbs9lAwRwYDVR0gBEAwPjA8BgsrBgEEAYGtYwEBAjAtMCsGCCsGAQUFBwIB
# Fh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMD4GCSsGAQQBgjcVBwQx
# MC8GJysGAQQBgjcVCIGshGGE4N8jguWdMoWbxFGBreUfgWqCypEWgqrlSQIBZAIB
# BTALBgNVHQ8EBAMCAYYwEgYDVR0TAQH/BAgwBgEB/wIBATAfBgNVHSMEGDAWgBQX
# 9m1ySznuzoXkg8QK2jhquzF3BTCBwAYDVR0fBIG4MIG1MIGyoIGvoIGshjVodHRw
# Oi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dhdGNoR3JvdXBSb290Q0ExLmNy
# bIZzbGRhcDovLy9DTj1Td2F0Y2hHcm91cFJvb3RDQTEsQ049Q0RQLENOPVB1Ymxp
# YyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24s
# REM9c3dhdGNoZ3JvdXAsREM9cm9vdDBRBggrBgEFBQcBAQRFMEMwQQYIKwYBBQUH
# MAKGNWh0dHA6Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2FpYS9Td2F0Y2hHcm91cFJv
# b3RDQTEuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQAN8/Vx9xrim7iEslVm9FEJ7hZT
# xHfPzQO9p06uClm5MID139O/GSy0U0Aa0anWzi9lkMRP+cmc3KY+SvtI1GUlSfnR
# pKVTxqKuX1BbmPDThFZStSbsTjYN4OZsJ4F+Ng+6ZDD3wwPlXPJ1Ht6aIZ3hgrvl
# sZrL2qHz/VOo2TCRmDOe6tr4KjJL3Ey+qFvaHmhQ1XNNgVA2oLxB5ACE9l3RHQEv
# oMDirdSm9COzvmlCAGXnDYfGJRuVqVpNvYIgQ0ipAympYqyL6Pvx1c8ProwKpXSs
# cZ0phJA/tiBcVplHH9ZZSFM2q/dH0gcqwM8OCahbdzu+Ht3B2Z14sKIaFi+UF8F5
# EC+c6wf0azUOuO+sLXpDHo1Vz3GO77xhj7pfzcvuxcru8IznTZwlFDujbCVUbh51
# rcyKMMQv9taqryi0lAuCgDU6p4k0iaGPxb+dXnBhYrM46IoSBK0tUz/w5ojk1i++
# cqVZI9XfyYrJYTAqfnxhNEldEYYPxCzni+dM2D+8TiCsC8Q89i3kT8HQkUkH7/6M
# r0keb7OVahtvl1XM+HiM60TEWXXH7dYlU6FgfhaoHSjwCr32gDTY9clb5UQgPuMQ
# DPpuk1AFoZD7sh/lUi0lPefEHNouWbgsaTiZnso8s/oJwJeG3nPwkXh9z9FSHcd9
# cvg8piR5mjUXKrlmfzGCAhgwggIUAgEBMGYwTzELMAkGA1UEBhMCQ0gxHTAbBgNV
# BAoTFFRoZSBTd2F0Y2ggR3JvdXAgTHRkMSEwHwYDVQQDExhTd2F0Y2ggR3JvdXAg
# U3lzdGVtIENBIDECEx4AAACUCPB16HlcgmMAAAAAAJQwDQYJYIZIAWUDBAIBBQCg
# gYQwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0B
# CQQxIgQgeqF/dbhkm7fKi/Dz5lL4X5joGmZ03+/iuIPnEnYP3DIwDQYJKoZIhvcN
# AQEBBQAEggEAp4zkBviTjJEJk9eoqg8tKrVnNkfCkpU8BjcqXPktZqdhGzqiOZpK
# 5xh4Jx/FYmXuC2YPTqar4g1SSy7su56LOjCf/mEJPcBzc5In0x5BAy9pynkeCAtn
# is+efxskA71hK0ZCKe6lx4YnJAmgmZTaQCyeEpPX5RpLcFpMOOxTKHFXeRkRGFtZ
# FS2ycFvP3jk1Nw2oEWFG85D6hZ4HHUPyACkbwcyM9/XMu5zT1FwCU4bfibDGg9ci
# YIw2fmDqoSkbLdH6bC3J8I3V48xO1de5Y8j3OJC0gtoetV+ZbrG3Aw8TlRlUEaos
# uk++O9it6PJAtkQmaWFsTycCN7VtiIMFuw==
# SIG # End signature block
