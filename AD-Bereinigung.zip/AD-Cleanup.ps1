# Set modes
param (
    [bool]$dummyRun = $false, # Set to $true to run the script in test mode with dummy data
    [bool]$useAdGroup = $false, # Set to $true to use AD groups instead of OUs
    [bool]$enableMetrics = $true, # Set to $true to enable metrics for the cleanup operation
    [bool]$readOnlyMode = $true, # Set to $true to run the script in read-only mode
    [bool]$sendMail = $true, # Set to $true to send a summary email after the cleanup operation
    [bool]$adgroupAnalytics = $true, # Set to $true to enable adgroup analytics
    [bool]$sendMailError = $true # Set to $true to send an error email if an error occurs during the cleanup operation
)

# Load Module
. "$PSScriptRoot\Modules\AD-Cleanup-ExportToCSV.ps1"

<#
.SYNOPSIS
Script for automating Active Directory cleanup.

.DESCRIPTION
This script automates the process of cleaning up Active Directory by disabling and removing inactive devices. It searches for devices in specified Organizational Units (OUs), checks if they meet certain exclusion criteria, and performs actions based on their last logon timestamp and existing comments.

.Variable readOnlyMode
Specifies whether the script should run in read-only mode. If set to $true, the script will only log actions without making any changes to Active Directory.

.Variable OUs
Specifies the OUs to search for devices. Devices within these OUs will be evaluated for cleanup.

.Variable disableDate
Specifies the date threshold for disabling devices. Devices with a last logon timestamp older than this date will be disabled.

.Variable deletionDelay
Specifies the number of days until devices are deleted. Devices that have been disabled for this duration will be deleted.

.Variable excludedADGroups
Specifies the AD groups to exclude from being disabled. Devices that are members of any of these groups will not be disabled.
.Variable excludedDivisionValues
Specifies the division values to exclude from being disabled. Devices with these division values will not be disabled.

.Variable excludedPatternsInComment
Specifies the patterns in the comment of the checked AD objects to exclude from being disabled. Devices with comments containing any of these patterns will not be disabled.

.Variable csvFilePath
Specifies the path to the CSV file where data will be exported. Default value is "C:\temp\File.csv".

.Variable logFilePath
Specifies the path to the log file where actions will be logged. Default value is "C:\temp".

.Variable logFileName
Specifies the name of the log file. The current date will be appended to the name. Default value is "AD-Cleanup_" followed by the current date in the format "dd_MM_yyyy".

.NOTES
This script requires the ActiveDirectory module to be imported.

How to call script (example):
.\AD-Cleanup.ps1 -dummyRun $false -useAdGroup $false -readOnlyMode $true -enableMetrics $false -sendMail $true -adgroupAnalytics $true -sendMailError $true

Author: Jan Niederhauser
Department: Workplace
Date: 06.01.2025
Version: 1.2.0
Release candidate: 
#>

# Import the necessary modules
Import-Module ActiveDirectory

# Set the variables
$OUs = @("OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the OUs to search @("OU=OU1,DC=domain,DC=com", "OU=OU2,DC=domain,DC=com") - "OU=AD-Test,OU=AdmMagnt-Test,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net"
$ADGroups = @("CN=ETACH-BS-AD-Test,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the AD groups to search if used instead of OU @("CN=Group1,OU=Groups,DC=domain,DC=com", "CN=Group2,OU=Groups,DC=domain,DC=com")
$disableDate = (Get-Date).AddDays(-50) # Set the disable date to 50 days ago
[int]$deletionDelay = 10 # Months until deleted
$deletionDate = (Get-Date).AddMonths($deletionDelay) # Set the deletion date to 10 months from now
$excludedADGroups = @("CN=ETACH-OT-Devices,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net", "CN=ETACH-OT-Candidates,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net", "CN=ETACH-Aktive-mGuard,OU=Groups,OU=ETACH,OU=ETA,OU=Companies,DC=swatchgroup,DC=net") # Specify the AD groups to exclude from being disabled
$excludedDivisionValues = @("6808") # Specify the division values to exclude from being disabled
$excludedPatternsInComment = @("[x]") # Specify the patterns in comment to exclude from being disabled -> @("[x]", "pattern2", "pattern3")
$targetDir = "$PSScriptRoot" # Specify the target directory for log files and exported data

# Set the target directory for log files and exported data if running in dummy mode
if ($dummyRun) {
    $targetDir = "C:\temp\dummyRun"
    $OUs = @("OU=TestOU,DC=domain,DC=com")
} # Specify the OUs to search in test mode

if ($useAdGroup) {
    $Groups = $ADGroups
}
else {
    $Groups = $OUs
}

$csvFilePath = "$targetDir\AD-Bereinigung_DeletedDevices.csv" # Specify the path to the CSV file
$csvSummary = "$targetDir\AD-BereinigungSummary.csv" # Specify the path to the csv summary file
$logFileNameBase = "AD-Cleanup_" # Specify the base name of the log file
$logFileName = "$logFileNameBase" + (Get-Date -Format dd_MM_yyyy)
$logFile = $targetDir + "\Logs\" + $logFileName + ".log"

# Initialize counters for logging
$amountDeleted = 0 # Where the device was deleted
$amountDisabled = 0 # Where the device was disabled in this run
$amountEnabled = 0 # Where the comment was removed
$amountNoTimestamp = 0 # Where the device had no timestamp
$amountCommentSet = 0 # Where the comment was ALREADY set (disabled)
$global:amountExcludedAdGroup = 0 # Where the device was excluded due to AD group
$global:amountExcludedDivision = 0 # Where the device was excluded due to division
$global:amountExcludedPattern = 0 # Where the device was excluded due to pattern
$amountError = 0 # Where an error occurred
$amountActive = 0 # Where the device was active

# Mail settings
$mailSender = "noreply@eta.ch" # Specify the email sender
$mailSmtpServer = "mail2019.swatchgroup.net" # Specify the SMTP server for sending emails

# Deletion Mail settings
$mailRecipient = "DSD@eta.ch"#,"digiinfra@eta.ch" # Specify the email recipients
$mailSubject = "Deleted Devices Summary" # Specify the email subject
$mailSubjectActionRequired = "[ACTION REQUIRED]" # Specify the subject prefix for action required emails

# Error Mail settings
$mailRecipientError = "jan.niederhauser@eta.ch", "zoltan.nyisztor@eta.ch", "toni.munafo@eta.ch" # Specify the email recipients
$mailSubjectError = "AD-Bereinung | Error" # Specify the email subject

# AD Group Analytics settings
$adgroupCsvLocation = "$targetDir\AD-Group-Analytics" # Specify the path to the CSV files for AD group analytics

# Various vars
$deviceDataList = $null
$deviceDataErrorList = $null

# Start logging all actions to a log file
Start-Transcript -Path $logFile

# Set up the AD group analytics
if ($adgroupAnalytics) {
    . "$PSScriptRoot\Modules\AD-Cleanup-GroupAnalytics.ps1"
    # Check if the AD group CSV location exists, if not create it
    if (-not (Test-Path -Path $adgroupCsvLocation)) {
        New-Item -ItemType Directory -Path $adgroupCsvLocation -Force
    }

    # Shorten the excluded AD groups into short names using a dictionary
    $shortNameDict = @{}
    foreach ($group in $excludedADGroups) {
        $shortName = ($group -split ',')[0] -replace '^CN=', ''
        $shortNameDict[$group] = $shortName
    }

    # Delete files in the AD group CSV location subfolder if it already exists
    Get-ChildItem -Path $adgroupCsvLocation -Recurse | Remove-Item -Force
}

# Create a function to check if a device should be excluded
function ShouldExcludeDevice($device) {
    # Check if the device is a member of any of the excluded AD groups
    foreach ($group in $excludedADGroups) {
        if ($device.MemberOf -contains $group) {
            $shortNameGroup = $shortNameDict[$group]
            Write-Host ("Device is in excluded AD-Group $shortNameGroup | '" + $device.Name + "'")
            $global:amountExcludedAdGroup++

            # Export the device to the AD group analytics CSV
            if ($adgroupAnalytics) {
                if ($device.lastLogonTimestamp -eq 0) {
                    Export-DeviceGroupAnalytics -deviceName $device.Name -group $shortNameGroup -lastlogontimestamp [datetime]::MinValue -csvLocation "$adgroupCsvLocation\$shortNameGroup.csv"
                }
                else {
                    [DateTime]$lastLogonTimestampException = [DateTime]::FromFileTime($device.lastLogonTimestamp)
                    Export-DeviceGroupAnalytics -deviceName $device.Name -group $shortNameGroup -lastlogontimestamp $lastLogonTimestampException -csvLocation "$adgroupCsvLocation\$shortNameGroup.csv"
                }
            }
            return $true
        }
    }

    # Check if the device has an excluded division value
    if ($excludedDivisionValues -contains ($device | Select-Object -ExpandProperty division)) {
        Write-Host ("Device is in excluded AD-Division '" + $device.Name + "'")
        $global:amountExcludedDivision++
        return $true
    }

    # Check if there is any defined pattern in the comment of the checked ad-object
    [string]$comment = ($device | Select-Object -ExpandProperty Description)
    foreach ($pattern in $excludedPatternsInComment) {
        $escapedPattern = $pattern -replace '\[', '`[' -replace '\]', '`]' # Escape the square brackets in the pattern for comparison because they are special characters in regex
        if ($comment -ilike "*$escapedPattern*") {
            Write-Host ("Device has a excluded pattern '" + $device.Name + "'")
            $global:amountExcludedPattern++
            return $true
        }
    }

    return $false
}

# Search for devices in the specified OUs
foreach ($group in ($Groups)) {
    if ($dummyRun) {
        . "$PSScriptRoot\Modules\AD-Cleanup.Tests.ps1"
        $ADList = $global:dummyData  # Assign the dummy data for testing
    }
    else {
        try {
            if ($useAdGroup) {
                $ADList = Get-ADGroupMember -Identity $group -Recursive | Where-Object { $_.objectClass -eq "computer" }
            }
            else {
                $ADList = Get-ADComputer -Filter * -SearchBase $group
            }
        }
        catch {
            Write-Output ("Error occurred while retrieving devices from group '" + $group + "': " + $_.Exception.Message)
            Write-Output ("Stopping the script")
            exit 1
        }
    }
    
    foreach ($comp in $ADList) {
        # Get the device's last logon timestamp
        if ($dummyRun) {
            $computerInformation = $comp
        }
        else {
            $retryCount = 0
            $maxRetries = 3
            $success = $false

            while ($retryCount -lt $maxRetries -and -not $success) {
                try {
                    $computerInformation = Get-ADComputer $comp.SamAccountName -Properties lastLogonTimestamp, Description, ms-Mcs-AdmPwd, Division, MemberOf, DistinguishedName
                    $success = $true
                }
                catch {
                    $retryCount++
                    Start-Sleep -Seconds 1
                    if ($retryCount -eq $maxRetries) {
                        Write-Output ("Error occurred while retrieving information for device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                        $amountError++
                    }
                }
            }

            if (-not $success) {
                # Skip to the next device if the information could not be retrieved
                continue
            }
        }

        # Check if the device should be excluded
        if (ShouldExcludeDevice($computerInformation)) {
            continue;
        }

        [long]$lastLogonTimestampValue = $computerInformation | Select-Object -ExpandProperty lastLogonTimestamp

        if ($lastLogonTimestampValue -ne 0) {
            # Convert the last logon timestamp to a DateTime object
            [DateTime]$lastLogonTimestamp = [DateTime]::FromFileTime($lastLogonTimestampValue)
        }
        else {
            Write-Output ("No last logon timestamp '" + $comp.SamAccountName + "'")
            $amountNoTimestamp++
            continue;
        }

        if ($lastLogonTimestamp -lt ($disableDate)) {
            # The device's last logon timestamp is older than 50 days

            # Check if there is an existing comment with a marked date of deletion
            [string]$comment = $computerInformation | Select-Object -ExpandProperty Description

            if ($comment -match "\[d\] \d{2}\.\d{4}_\d{2}\.\d{4}_#") {
                # There is an existing comment with a marked date of deletion
                
                # Get the marked date of deletion from the comment
                [string]$markedDeletionDate = ($comment.Substring(($comment.IndexOf("[d]") + 12), 7))
                [int]$markedDeletionMonth = [int]$markedDeletionDate.Substring(0, 2)
                [int]$markedDeletionYear = [int]$markedDeletionDate.Substring(3, 4)

                # Check if the current month and year is equal to or later than the marked date of deletion
                if ((Get-Date).Year -gt $markedDeletionYear -or ((Get-Date).Year -eq $markedDeletionYear -and (Get-Date).Month -ge $markedDeletionMonth)) {
                    # The current month and year is equal to or later than the marked date of deletion

                    $dontDelete = $false
                    $errorInformation = @()

                    # Export the BitLocker key, LAPS password, client name, and deletion date to a CSV file
                    try {
                        #$bitLockerKey = (Get-ADObject -Filter 'objectClass -eq "msFVE-RecoveryInformation"' -SearchBase $comp.DistinguishedName -Properties msFVE-RecoveryPassword | Select-Object -ExpandProperty msFVE-RecoveryPassword) | Select-Object -Index 0
                        $bitlockerKey = Get-ADObject -Filter 'objectClass -eq "msFVE-RecoveryInformation"' -SearchBase $comp.DistinguishedName -Properties whenCreated, msFVE-RecoveryPassword | `
                            Sort-Object whenCreated -Descending | Select-Object whenCreated, msFVE-RecoveryPassword
                    }
                    catch {
                        Write-Output ("Error occurred while retrieving BitLocker key for device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                        $amountError++
                        $errorInformation += "Bitlocker"
                        $dontDelete = $true
                    }

                    # Check if the device exists in AD before attempting to retrieve the LAPS password
                    try {
                        Get-ADComputer -Identity $comp.SamAccountName
                    }
                    catch {
                        Write-Output ("Device '" + $comp.SamAccountName + "' does not exist in AD: " + $_.Exception.Message)
                        $errorInformation += "AD Error"
                        $amountError++
                    }

                    if ($errorInformation -notcontains "AD Error") {
                        try {
                            $lapsPassword = (Get-LapsADPassword -Identity $comp.Name -AsPlainText).Password
                        }
                        catch {
                            Write-Output ("Error occurred while retrieving LAPS password for device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                            $amountError++
                            $errorInformation += "LAPS"
                            $dontDelete = $true
                        }
                    }
                    else {
                        # If the device does not exist in AD, do not attempt to retrieve the LAPS password but add it to the error information
                        $errorInformation += "LAPS"
                        $amountError++
                    }

                    $clientName = $comp.SamAccountName
                    $deletionDate = Get-Date
                    $costCenter = $computerInformation | Select-Object -ExpandProperty Division
                    $memberOF = ($computerInformation | Select-Object -ExpandProperty MemberOf) -join " ,"
                    $OU = ($computerInformation | Select-Object -ExpandProperty DistinguishedName) -join " ,"
                    $data = [pscustomobject]@{
                        "Deletion Date" = $deletionDate
                        "Client Name"   = $clientName
                        "BitLocker Key" = $bitLockerKey
                        "LAPS Password" = $lapsPassword
                        "Cost Center"   = $costCenter
                        "Member Of"     = $memberOF
                        "OU"            = $OU
                        "Description"   = $comment
                    }

                    if (!$readOnlyMode) {
                        # Remove the device from AD
                        try {
                            $computerInformation | Remove-ADObject -Recursive -Confirm:$false
                        }
                        catch {
                            Write-Output ("Error occurred while removing device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                            $amountError++
                            continue
                        }
                        
                    }
                    # Add the data to array
                    if (-not $deviceDataList) {
                        $deviceDataList = @()
                    }
                                        
                    if (!$dontDelete) {
                        ExportToCSV -csvFilePath $csvFilePath -data $data
                        $deviceDataList += @(
                            @{
                                'Client Name' = $data.'Client Name'
                            }
                        )
                    }
                    else {
                        if (-not $deviceDataErrorList) {
                            $deviceDataErrorList = @()
                            $mailSubject = "$mailSubjectActionRequired $mailSubject"
                        }
                        $deviceDataErrorList += @(
                            @{
                                'Client Name' = $data.'Client Name'
                                'Error Type'  = ($errorInformation -join ', ')
                            }
                        )

                    }

                    $amountDeleted++
                    # Log the deletion action
                    Write-Output ("Deleted device '" + $comp.SamAccountName + "'")

                    $data = $null
                }
                else {
                    # The current month and year is earlier than the marked date of deletion
                    Write-Output ("Device '" + $comp.SamAccountName + "' is not yet due for deletion, marked deletion date: " + $markedDeletionDate)
                    $amountCommentSet++
                }
            }
            else {
                # There is no existing comment with a marked date of deletion
                # Disable the device
                # Create a comment on the device before the existing comment following the specified pattern
                [string]$disableMonthYear = (Get-Date).ToString("MM.yyyy")
                [string]$deletionMonthYear = (Get-Date).AddMonths($deletionDelay).ToString("MM.yyyy")
                [string]$newComment = "[d] " + ($disableMonthYear) + "_" + ($deletionMonthYear) + "_#"
                $fullComment = ($newComment + " " + ($computerInformation | Select-Object -ExpandProperty Description))

                if (!$readOnlyMode) {
                    try {
                        Set-ADComputer -Identity $comp.SamAccountName -Description $fullComment
                    }
                    catch {
                        Write-Output ("Error occurred while setting description for device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                        $amountError++
                        continue
                    }

                    # Disable the device in AD
                    try {
                        Disable-ADAccount -Identity $comp.SamAccountName
                    }
                    catch {
                        Write-Output ("Error occurred while disabling account for device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                        $amountError++
                        continue
                    }
                }

                $amountDisabled++

                # Log the disable action
                Write-Output ("Disabled device '" + $comp.SamAccountName + "'" + " $fullComment set as description - LastLogonTimestamp: " + $lastLogonTimestamp)
            }
        }
        else {
            # The device's last logon timestamp is not older than 50 days

            # Check if there is an existing comment with a marked date of deletion
            [string]$comment = ($computerInformation | Select-Object -ExpandProperty Description)
            if ($comment -match "\[d\] \d{2}\.\d{4}_\d{2}\.\d{4}_#") {
                # There is an existing comment with a marked date of deletion

                [int]$startIndex = ($comment.IndexOf("[d]"))
                [int]$endIndex = ($comment.IndexOf("_#") + 2)
                $remainingComment = $comment.Remove($startIndex, ($endIndex - $startIndex))

                if (!$readOnlyMode) {
                    # Set to $null because if the remaining comment is empty, the Set-ADComputer cmdlet will throw an error
                    if ($remainingComment -eq "") {
                        $remainingComment = $null
                    }
                    try {
                        # Remove the created comment between the symbol [d] and _#
                        Set-ADComputer -Identity $comp.SamAccountName -Description $remainingComment
                    }
                    catch {
                        Write-Output ("Error occurred while removing comment from device '" + $comp.SamAccountName + "': " + $_.Exception.Message)
                        $amountError++
                        continue
                    }
                }

                $amountEnabled++

                # Log the removal action
                Write-Output ("Removed comment from device '" + $comp.SamAccountName + "'" + ", remaining comment: " + $remainingComment)
            }
            else {
                $amountActive++
            }
        }
    }
}

if ($sendMail -and ($deviceDataList -or $deviceDataErrorList)) {
    . "$PSScriptRoot\Modules\AD-Cleanup-MailModule.ps1"
    SendADSummaryMail -mailRecipient $mailRecipient -mailSender $mailSender -mailSubject $mailSubject -mailSmtpServer $mailSmtpServer -deletedDevices $deviceDataList -deletedDevicesErrors $deviceDataErrorList -mailMode "delete"
}

if ($amountError -gt 0 -and $sendMailError) {
    . "$PSScriptRoot\Modules\AD-Cleanup-MailModule.ps1"
    SendADSummaryMail -mailRecipient $mailRecipientError -mailSender $mailSender -mailSubject $mailSubjectError -mailSmtpServer $mailSmtpServer -mailMode "error"
}

# Create a summary of the cleanup operation
if ($enableMetrics) {
    . "$PSScriptRoot\Modules\AD-Cleanup-Metrics.ps1"
    $summary = New-Summary -amountDeleted $amountDeleted -amountDisabled $amountDisabled -amountEnabled $amountEnabled -amountNoTimestamp $amountNoTimestamp -amountCommentSet $amountCommentSet -amountExcludedAdGroup $global:amountExcludedAdGroup -amountExcludedDivision $global:amountExcludedDivision -amountExcludedPattern $global:amountExcludedPattern -amountError $amountError -amountActive $amountActive -filePath $csvSummary
    
    Write-Output "Summary of AD Cleanup Metrics:"
    Write-Output $summary
}

# Delete .log files older than 365 days
Get-ChildItem -Path $targetDir -Filter "$logFileNameBase*.log" -Recurse | Where-Object { $_.LastWriteTime -lt (Get-Date).AddDays(-365) } | Remove-Item -Force

# Stop logging all actions to a log file
Stop-Transcript
# SIG # Begin signature block
# MIIQ9QYJKoZIhvcNAQcCoIIQ5jCCEOICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC4Hmuk0pIehmzj
# 8dSKuS0s6PpkigSs4DmWXkXOjjf5M6CCDjMwggbqMIIE0qADAgECAhMeAAAAlAjw
# deh5XIJjAAAAAACUMA0GCSqGSIb3DQEBCwUAME8xCzAJBgNVBAYTAkNIMR0wGwYD
# VQQKExRUaGUgU3dhdGNoIEdyb3VwIEx0ZDEhMB8GA1UEAxMYU3dhdGNoIEdyb3Vw
# IFN5c3RlbSBDQSAxMB4XDTE2MDcyODExNDMyMloXDTI2MDcyNjExNDMyMlowaTEL
# MAkGA1UEBhMCQ0gxLDAqBgNVBAoTI0VUQSBTQSBNYW51ZmFjdHVyZSBIb3Jsb2dl
# cmUgU3Vpc3NlMSwwKgYDVQQDEyNFVEEgU0EgTWFudWZhY3R1cmUgSG9ybG9nZXJl
# IFN1aXNzZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALCaXuMxl+6o
# EqiCctaFpBEq7jud9VDOnqHbShjqEHEYP7ove3opkeGcWzHyl7JdIEfPageeqGW3
# BLhSHN63kC/KZiTtQ4XSJjSsN4KiQwZsPtk3kHQAJnTsT5oOFJXlMYYmKqdU9uZ2
# ar8USjYB0XdCvXzCZRRdE14pPbGAGVVD9AsdWVMOjMvq7vKWGrfSRrVUsw1qlnYQ
# 3A5NOQ7pjsrXffEUnrXUq+1QYUOqeFfWWcm8zZPY+jkt/T8b4GZxu1tYDpUCFFfH
# CAOl/rn2ezO+HFI2q2ZZY/MWL19T0UzjJEFkUaBShBMGlqXm7w6/4OUfBWair2sS
# 0k+NtLvqircCAwDk/aOCAqMwggKfMB0GA1UdDgQWBBR9eUv4jpidbNOnZKKl4xmU
# boizmjAfBgNVHSMEGDAWgBS9E59YiOJVatuTbc0Ugk1Jxuz2UDCBxAYDVR0fBIG8
# MIG5MIG2oIGzoIGwhjdodHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dh
# dGNoR3JvdXBTeXN0ZW1DQTEuY3JshnVsZGFwOi8vL0NOPVN3YXRjaEdyb3VwU3lz
# dGVtQ0ExLENOPUNEUCxDTj1QdWJsaWMlMjBLZXklMjBTZXJ2aWNlcyxDTj1TZXJ2
# aWNlcyxDTj1Db25maWd1cmF0aW9uLERDPXN3YXRjaGdyb3VwLERDPXJvb3QwgYEG
# CCsGAQUFBwEBBHUwczBDBggrBgEFBQcwAoY3aHR0cDovL3BraS5zd2F0Y2hncm91
# cC5uZXQvYWlhL1N3YXRjaEdyb3VwU3lzdGVtQ0ExLmNydDAsBggrBgEFBQcwAYYg
# aHR0cDovL29jc3Auc3dhdGNoZ3JvdXAubmV0L29jc3AwPgYJKwYBBAGCNxUHBDEw
# LwYnKwYBBAGCNxUIgayEYYTg3yOC5Z0yhZvEUYGt5R+BaoPO7CGGxYltAgFkAgEQ
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMAsGA1UdDwQEAwIHgDAMBgNVHRMBAf8EAjAA
# MIGEBgNVHSAEfTB7MDwGCysGAQQBga1jAQECMC0wKwYIKwYBBQUHAgEWH2h0dHA6
# Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2NwcwAwOwYKKwYBBAGBrWMCBDAtMCsGCCsG
# AQUFBwIBFh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMBsGCSsGAQQB
# gjcVCgQOMAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggIBADuWU1pXOXUt
# pPBDltPRhQO4SCIIW7jMuS7xcd1Azh7KHIhWw1ZDR3rjypiFwRwUfX/3KHRIVWKn
# jZCiFcaywf1MtJqFfpB5Ewjf84vOk8AW18fFOX9CoTKVQsszHY6Dr3+XVW8CV0s3
# /YAuHLd/zdkQ4i5GvROrX2Mt2l+IQ6yM688pqI3KNcvzF2lElGLtTII3Wouk0mYs
# VtsKRtvlPO8qiJoQlKhJo3MTdUgB4kxSDaDcofvWy51wAVQD7kjENXjgyYK1FGw4
# 6aTNvWg0rxwGt52J8TreXSKAxRjcg9hrbOdu81b3rfaV8MJKWLgA8iLn5JmBIfBt
# zj92o2QaVe5nCO1LDq51vxSHpiqxHgHaEDAOdQNy4ImF+grt63S/IWSBuHJiEbUl
# FgL+OMiSHHwI8Y3NopYrVCAIw1FVx2JyXxn5Hd0bqRVslS7Ao1jWHDbWXvRE9LKG
# Xa+HeFhfh8e7HCGiAcaMTjf0z9/ELELWCUVkxmta/xjILyDK3DFAmrNdKiC5/vYt
# aNVZ4g8Z/C3JeIdsnNzQEI5TODyu4jmQ2QgDvbN97DvHYw8mGX7KT9KbiYTY7tHR
# K2r+b+EbjUMnRf0BtZY9C82b4vKUCC8U6ZtVV4HYE/uEOF3x184LOjaNlHFvOJEf
# zhgahrEc3/mFHN/WEbCQ+7u4zPAyCfrjMIIHQTCCBSmgAwIBAgITEQAAAASHw0YH
# OuspOwAAAAAABDANBgkqhkiG9w0BAQsFADBNMQswCQYDVQQGEwJDSDEdMBsGA1UE
# ChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxHzAdBgNVBAMTFlN3YXRjaCBHcm91cCBS
# b290IENBIDEwHhcNMTYwNTA5MTIwNTU1WhcNNDEwNTAzMTIwNTU1WjBPMQswCQYD
# VQQGEwJDSDEdMBsGA1UEChMUVGhlIFN3YXRjaCBHcm91cCBMdGQxITAfBgNVBAMT
# GFN3YXRjaCBHcm91cCBTeXN0ZW0gQ0EgMTCCAiIwDQYJKoZIhvcNAQEBBQADggIP
# ADCCAgoCggIBAOxciJUVJemY6TixhlEqniQwIZSDeYuQo45nNeRNWISMI7scaG4Z
# fdhLLwFm0x0vRF50b0OBKYkcnsV/t0eaZn3PZvzbLyLNqWeQ5d3aQeYw8iFfoPAe
# HYp1vzYWs98cDxxFwebwP5I+iBueUWSWC4DgKc/vYWfZSMexaKrLnSYMnU4PsCgz
# bEt+NUkGGR68pWgbaX2dE5jplW5OiDltKElVzwLLcWjZD7LC+4nY+u2woMct0kNB
# YD5k9QA0nVRHE7GPRRQYsYF1i3CRmIHaOqS+RjvguUmkImvbDbyBarjEJnFcsK+c
# XKPaVHbtJU6rByh1q4DVcczZ55wKU6LGGZTUOXNEgMm/vamSfw4eIrIeDtGTY0hc
# yhznSENFUgN7/8qqn5t1giOt4B1iMU8cOAv0orhgf0VHQVRxYJkIq0AnsSJkhfGy
# geS/5x/qAFUBmbseuw8GSTWWe0gj31YfuTbXLNu7DrjffGNgxbBR92iDs7y14rab
# kVrjayluVhJRp0ou4Wkg6b7gEhISS5DMgdPffsCNikhc7MmfYLU5AurG87YYQa5l
# Vtzo5pGis768hnfShJrHdKQockNtG+3KoHP0LEGBXvgio71MB8MhE1zwyWkqaXQq
# itmtgpDe+J5twOfz5zqcfRbQB3Dp5WBoevoUSe2c5Nn+USgsx1WMcYxPAgMBAAGj
# ggIWMIICEjAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQUvROfWIjiVWrbk23N
# FIJNScbs9lAwRwYDVR0gBEAwPjA8BgsrBgEEAYGtYwEBAjAtMCsGCCsGAQUFBwIB
# Fh9odHRwOi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcHMAMD4GCSsGAQQBgjcVBwQx
# MC8GJysGAQQBgjcVCIGshGGE4N8jguWdMoWbxFGBreUfgWqCypEWgqrlSQIBZAIB
# BTALBgNVHQ8EBAMCAYYwEgYDVR0TAQH/BAgwBgEB/wIBATAfBgNVHSMEGDAWgBQX
# 9m1ySznuzoXkg8QK2jhquzF3BTCBwAYDVR0fBIG4MIG1MIGyoIGvoIGshjVodHRw
# Oi8vcGtpLnN3YXRjaGdyb3VwLm5ldC9jcmwvU3dhdGNoR3JvdXBSb290Q0ExLmNy
# bIZzbGRhcDovLy9DTj1Td2F0Y2hHcm91cFJvb3RDQTEsQ049Q0RQLENOPVB1Ymxp
# YyUyMEtleSUyMFNlcnZpY2VzLENOPVNlcnZpY2VzLENOPUNvbmZpZ3VyYXRpb24s
# REM9c3dhdGNoZ3JvdXAsREM9cm9vdDBRBggrBgEFBQcBAQRFMEMwQQYIKwYBBQUH
# MAKGNWh0dHA6Ly9wa2kuc3dhdGNoZ3JvdXAubmV0L2FpYS9Td2F0Y2hHcm91cFJv
# b3RDQTEuY3J0MA0GCSqGSIb3DQEBCwUAA4ICAQAN8/Vx9xrim7iEslVm9FEJ7hZT
# xHfPzQO9p06uClm5MID139O/GSy0U0Aa0anWzi9lkMRP+cmc3KY+SvtI1GUlSfnR
# pKVTxqKuX1BbmPDThFZStSbsTjYN4OZsJ4F+Ng+6ZDD3wwPlXPJ1Ht6aIZ3hgrvl
# sZrL2qHz/VOo2TCRmDOe6tr4KjJL3Ey+qFvaHmhQ1XNNgVA2oLxB5ACE9l3RHQEv
# oMDirdSm9COzvmlCAGXnDYfGJRuVqVpNvYIgQ0ipAympYqyL6Pvx1c8ProwKpXSs
# cZ0phJA/tiBcVplHH9ZZSFM2q/dH0gcqwM8OCahbdzu+Ht3B2Z14sKIaFi+UF8F5
# EC+c6wf0azUOuO+sLXpDHo1Vz3GO77xhj7pfzcvuxcru8IznTZwlFDujbCVUbh51
# rcyKMMQv9taqryi0lAuCgDU6p4k0iaGPxb+dXnBhYrM46IoSBK0tUz/w5ojk1i++
# cqVZI9XfyYrJYTAqfnxhNEldEYYPxCzni+dM2D+8TiCsC8Q89i3kT8HQkUkH7/6M
# r0keb7OVahtvl1XM+HiM60TEWXXH7dYlU6FgfhaoHSjwCr32gDTY9clb5UQgPuMQ
# DPpuk1AFoZD7sh/lUi0lPefEHNouWbgsaTiZnso8s/oJwJeG3nPwkXh9z9FSHcd9
# cvg8piR5mjUXKrlmfzGCAhgwggIUAgEBMGYwTzELMAkGA1UEBhMCQ0gxHTAbBgNV
# BAoTFFRoZSBTd2F0Y2ggR3JvdXAgTHRkMSEwHwYDVQQDExhTd2F0Y2ggR3JvdXAg
# U3lzdGVtIENBIDECEx4AAACUCPB16HlcgmMAAAAAAJQwDQYJYIZIAWUDBAIBBQCg
# gYQwGAYKKwYBBAGCNwIBDDEKMAigAoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYB
# BAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0B
# CQQxIgQgHjrUPjDdzPEHSd1D1/qP5+tOFNBQJQ7LpOTuFNz92A8wDQYJKoZIhvcN
# AQEBBQAEggEALeZk3BYs0WdWKrcjgGy9y/FxHOUBuyZuJI8LXn+29w72OMVN26lf
# 6fBtCbUNoSf769k90jtNhcgppyCr/0HAwL79wA2FSl/jDMZ2XiJENkXVE5+lnQDH
# cpZ+iN6LwjidoztCkS0w1Em3IpNKaD0v+o06YScKnZD22M253dqwF2o6zajuORta
# d5/se8+YOk7MnodVEmUfvzc3k5piYv85AkDQzo3ia6B1XtLYVEpWxOYEINijx3Ni
# xL3lnWq6tnhfjYibvkGZ9RUhZ2uyUyUYBN9PFUYd4ZXEX2Wxeu/N2t9Nn94NGZXW
# SfkddlJIioUvFFMn2VK4Y2f0AtwFisRZqQ==
# SIG # End signature block
